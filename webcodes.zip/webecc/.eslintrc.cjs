module.exports = {
  root: true,
  parser: 'vue-eslint-parser',
  env: {
    browser: true,
    es2021: true,
    node: true
  },
  extends: [
    'airbnb-baset', 
    'plugin:vue/vue3-essential',
    'plugin:vue/vue3-essential', // 使用 eslint-plugin-vue 中 vue3-essential 配置项的规则集合
    'plugin:prettier/recommended', // 使用 eslint-plugin-prettier 中 recommended 配置项的规则集合
  ],
  parserOptions: {
    ecmaVersion: 'latest', // 指定要解析的 ECMAScript 版本
    sourceType: 'module', // 指定 ECMAScript 模块的类型
    parser: '@typescript-eslint/parser', // 指定解析器
  },
  plugins: [
    'vue',
    '@typescript-eslint'
  ],
  rules: {
    'import/no-unresolved': 'off',
    'import/extensions': 'off',
    'import/no-extraneous-dependencies': 0,
    'vue/multi-word-component-names': [
      'error',
      {
        ignores: ['index', '403', '404', '500'], // 需要忽略的组件名
      },
    ],
    // 处理 prettier 和 eslint 冲突的规则
    'prettier/prettier': [
      'error',
      {
        printWidth: 80,
        singleQuote: true,
        semi: true,
      },
    ],
    "vue/no-unused-components": "off"
  }
}
