# Vue 3 + TypeScript + Vite + ant-design-vue + pnpm + pinia + router

# 启动

安装依赖
node： v18.15.0 
安装pnpm:   npm install -g pnpm
安装依赖:   pnpm install  
- 运行

```bash
pnpm dev
```
- 清除缓存运行 热更新失败这样启动

pnpm force
- 打包

```bash
pnpm build  强校验
pnpm builds 

```
## 结构目录

|-- public
|-- src
|   |-- api                                        api接口文件集合
|       |-- http.ts                                公共请求封装
|       |-- common                                 公共请求集合
|       |-- other                                  其他等请求
|   |-- assets                                     静态文件
|   |-- components                                 组件 与 bpmn.js 自定义模块
|       |-- common                                 公共组件
|   |-- hooks                                      hooks文件公共处理
|   |-- layout                                     布局文件
|   |-- router                                     路由文件
|       |-- guard                                  路由守卫等逻辑编写
|       |-- modules                                路由集合
|       |-- index.ts                               根路由
|       |-- modules-index.ts                       模块集合
|   |-- store
|       |-- index.ts                               pini状态管理
|   |-- theme
|       |-- index.less                             项目样式统一入口
|       |-- default.less                           默认样式
|   |-- utils                                      工具类
|   |-- view                                       页面
|   |-- App.vue
|   |-- main.ts
|-- README.md                                      说明
|-- tsconfig.json
|-- package.json
|-- vite.config.js                                 配制文件