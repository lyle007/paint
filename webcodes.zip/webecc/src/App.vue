<template>
  <ConfigProvider :locale="zhCN">
    <router-view></router-view>
    <mesasagepop></mesasagepop>
  </ConfigProvider>
</template>

<script setup lang="ts">
import { onBeforeMount} from 'vue'
// import { commonSet } from '@/api/common/index'; // 原动态主题配制
import { ConfigProvider } from 'ant-design-vue';
import zhCN from 'ant-design-vue/es/locale/zh_CN';


import mesasagepop from './components/messagepop/index.vue'

// 连接socket
import { useCounterStore } from "./store/index";
const useStore = useCounterStore()
if (!window.location.hash.includes('login')) {
  const { connect } = useStore
  connect()
}

onBeforeMount(() => {
  /***  原主题色配制  ***/
  // commonSet({ tenant_id: 'msap' }).then((res: any) => {
  //   if (res.code == 0) {
  //     ConfigProvider.config({
  //       theme: {
  //         primaryColor: res.theme_color,
  //         infoColor: res.theme_second_color,
  //       }
  //     });
  //     localStorage.setItem('platformInfo', JSON.stringify(res.data))
  //   }
  // })
})
</script>

<style scoped lang="less"></style>
