

import  douMtHttp  from '../http';


import  axiosInstance from '../http';
/**
 * @auth phy
 * 说明：群列表， 豆豆接口和mt接口的；
 */
export function getgrouplist (data: any = {}) {
  return douMtHttp({
    url: `/kucunList`,
    method: 'post',
    data: data,
  })
}
/**
 * @auth phy
 * 说明：群详情， 豆豆接口和mt接口的；
 */
export function getgroupd (id) {
  return douMtHttp({
    url: `//kucu/${id}`,
    method: 'post',
  })
}
/**
 * @auth phy
 * 说明：创建群， 豆豆接口和mt接口的；
 */
export function createGroup (params: any = {}) {
  return douMtHttp({
    url: `/ecs/api/v1.0/admin/dood/group/create`,
    method: 'post',
    data: params,
  })
}
/**
 * @auth phy
 * 说明：更新群， 豆豆接口和mt接口的；
 */
export function updateGroup (params: any = {}) {
  return douMtHttp({
    url: `/kucun`,
    method: 'post',
    data: params,
  })
}
/**
 * @auth phy
 * 说明：移除群， 豆豆接口和mt接口的；
 */
export function removeGroup (params: any = {}) {
  return douMtHttp({
    url: `/ecs/api/v1.0/admin/dood/group/remove`,
    method: 'post',
    data: params,
  })
}

/**
 * @auth phy
 * 说明：获取所有用户 豆豆接口和mt接口的；
 */

 export function getAllUser(params: any = {}) {
  return douMtHttp({
    url: `/ecs/api/v1.0/admin/dood/org/getAllUser`,
    method: 'post',
    data: params,
  })
}
/**
 * @auth phy
 * 说明：获取群成员 豆豆接口和mt接口的；
 */

 export function getMembers(params: any = {}) {
  return douMtHttp({
    url: `/ecs/api/v1.0/admin/dood/group/getMembers`,
    method: 'post',
    data: params,
  })
}
/**
 * @auth phy
 * 说明：添加群成员 豆豆接口和mt接口的；
 */

 export function addMembers(params: any = {}) {
  return douMtHttp({
    url: `/ecs/api/v1.0/admin/dood/group/addMembers`,
    method: 'post',
    data: params,
  })
}
/**
 * @auth phy
 * 说明：移除群成员 豆豆接口和mt接口的；
 */

 export function removeMembers(params: any = {}) {
  return douMtHttp({
    url: `/ecs/api/v1.0/admin/dood/group/removeMembers`,
    method: 'post',
    data: params,
  })
}
/**
 * @auth phy
 * 说明同步用户：豆豆接口和mt接口的；
 */

 export function synchronous(params: any = {}) {
  return douMtHttp({
    url: `/ecs/api/v1.0/admin/dood/sync_org_user`,
    method: 'post',
    data: params,
  })
}


/****
 * 
 * 新的获取消息 人员接口
 * 
 */

 export function getAllUserNew(params: any = {}) {
  return axiosInstance({
    url: `/userList`,
    method: 'post',
    data: params,
  })
}