import axios, {
  AxiosResponse,
  AxiosError,
  InternalAxiosRequestConfig,
} from 'axios';

import { message } from 'ant-design-vue';
import { router } from '@/router/index';



const BASE_URL_PREFIX = import.meta.env.VITE_API_BASEURL;

const axiosInstance = axios.create({
  baseURL: BASE_URL_PREFIX,
  timeout: 1000 * 30,
  headers: {
    'Content-Type': 'application/json',
  },
});

// 请求拦截器
axiosInstance.interceptors.request.use(
  (config: InternalAxiosRequestConfig) => {
    if (sessionStorage.getItem('access_token')) {
      config.url = `${config.url}?access_token=${sessionStorage.getItem('access_token')}`
    }
    return config;
  },
  (error: AxiosError) => {
    return Promise.reject(error);
  },
);

// 响应拦截器
axiosInstance.interceptors.response.use(
  (response: AxiosResponse) => {
    if (response.data.code === 0 || response.config.responseType == 'blob') {
      return response.data;

    } else {
      message.error(response.data.message)
      return Promise.reject(response.data);
    }
  },
  (error: any) => {
    message.warning(error.message)
    if (error.response.status == 401) {
      window.sessionStorage.clear();
      setTimeout(() => {
        router.push({
          path: '/login'
        })
      }, 500)
    }
    return Promise.reject(error);
  },
);



export default axiosInstance;
