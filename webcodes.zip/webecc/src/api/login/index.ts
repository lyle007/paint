import axiosInstance from "@/api/http";
import { enCode } from '@/utils/crypto';
import cloneDeep from 'clone-deep';
/**
 * @auth phy
 * 说明：登录管理员登录；
 */
export function loginToken(params: any) {
  // params = cloneDeep(params)
  // params['grant_type'] = 'password';
  // params['client_id'] = 'system';
  // params['client_secret'] = 'secret';
  // params['is_login'] = '1';
  // params['username'] = params['account'];
  // params['password'] = enCode('MEAP@AES218@MEAP',params['password']);
  // params['password2'] = params['password2'] ? enCode('MEAP@AES218@MEAP',params['password2']) : '';
  // params['password3'] = params['password3'] ? enCode('MEAP@AES218@MEAP',params['password3']) : '';
  // return axiosInstance({
  //   url: `/uaa/api/v1.0/admin/user/oauth_token`,
  //   method: 'post',
  //   data: params,
  //   headers: {
  //     'Mt-Tenant': params['tenant_id']
  //   }
  // })
  const cloneParams = cloneDeep(params);
  cloneParams.password = enCode('MEAP@AES218@MEAP', cloneParams['password']);
  cloneParams['username'] = cloneParams['account'];
  return axiosInstance({
    url: `/login`,
    method: 'post',
    params: cloneParams
  })
}
export function getAdmin() {
  return axiosInstance({
    url: `/uaa/api/v1.0/admin/user/user_info`,
    method: 'post'
  })
}

// 刷新验证码
export function getVerImg(udid: string, tenant_id: string) {
  return axiosInstance({
    url: `/uaa/api/v1.0/admin/user/captcha/${udid}?id=${tenant_id}`,
    method: 'get',
    responseType: 'blob',
    headers: {
      'Mt-Tenant': tenant_id
    }
  })
}
/**
 * @auth phy
 * 说明：用户登录 ；
 */
export function userToken(params: any) {
  const cloneParams = cloneDeep(params);
  cloneParams.password = enCode('MEAP@AES218@MEAP', cloneParams['password']);
  cloneParams['tenant_id'] = 'msap';
  cloneParams['role'] = 'USER';
  cloneParams['ver'] = '';
  cloneParams['grant_type'] = 'password';
  cloneParams['captcha_skip'] = '';
  cloneParams['cas_token'] = '';
  cloneParams['client_secret'] = 'secret';
  cloneParams['client_id'] = 'sap';
  return userlogin({
    url: `/uaa/oauth/token`,
    method: 'post',
    params: cloneParams
  })
}
/**
 * @auth phy
 * 说明：用户登录信息 ；
 */
export function findEnc() {
  return userlogin({
    url: `/uaa/api/v1.0/user/user_info`,
    method: 'post',
  })
}
