import axiosInstance from "@/api/http";


/**
 * @auth phy
 * 说明 获取用户
 */

 export function getUserData(data: any) {
  const  user = JSON.parse(sessionStorage.getItem('user')|| '');
  if(user.role == 'ADMIN') {
    return axiosInstance({
      url: `/sap/api/v1.0/admin/user/find_all`,
      method: 'post',
      data: data
    })
  } else{
    return axiosInstance({
      url: `/ecs/api/v1.0/common/forward_meap`,
      method: 'post',
      data: {
        url: "/sap/api/v1.0/admin/user/find_all",
        body_param: JSON.stringify(data)
      }
    })
  }
 
}

/**
 * @auth phy
 * 获取已经分配的组织用户
 */

 export function members(url: string, data: any) {
  return axiosInstance({
    url: url,
    method: 'post',
    data: data
  })
}

/**
 * @auth phy
 * 分配 
 */
 export function distribute(url: string, data: any) {
  return axiosInstance({
    url: url,
    method: 'post',
    data: data
  })
}


