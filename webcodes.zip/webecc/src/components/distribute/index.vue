<template>
  <div>
    <a-modal :visible="props.visible" title="分发" width="80%" class="distribute" @cancel="onCancel">
      <a-tabs v-model:activeKey="activeKey">
        <a-tab-pane key="org" tab="按机构">
          <org :memberUrl="props.memberUrl" :rowData="props.rowData" :readonly="props.readonly" @getBody="getBody"></org>
        </a-tab-pane>
        <a-tab-pane key="user" tab="按用户">
          <user :memberUrl="props.memberUrl" :rowData="props.rowData" :readonly="props.readonly" @getBody="getBody"></user>
        </a-tab-pane>
      </a-tabs>
      <template #footer>
        <a-button key="submit" type="primary" @click="handleOk" v-if="!props.readonly">分配</a-button>
      </template>
    </a-modal>

  </div>
</template>

<script setup lang="ts">
import { ref, watch } from 'vue';
import org from './org.vue'; // 机构
import user from './user.vue'; // 用户
const activeKey = ref('org');
import { distribute } from './api'
const props = defineProps({
  memberUrl: { // 获取已分配的组织用户的 url
    type: String,
  },
  distributeUrl: { // 分配组织用户的 url
    type: String,
    default() {
      return '/sap/api/v1.0/admin/message/distribute'
    }
  },
  readonly: {
    type: Boolean,
    default() {
      return false
    }
  },
  rowData: {
    type: Object
  },
  visible: {
    type: Boolean,
    default() {
      return false
    }
  }
})
watch(() => props.rowData, (value: any) => {
  if (value.cul_bind) {
    activeKey.value = value.cul_bind;
  }else{
    activeKey.value = 'org';
  }
}, {
  immediate: true,
  deep: true
})
const handleOk = () => {
  distribute(props.distributeUrl, dataBody.value).then(() => {
    onCancel()
  })
}
const dataBody = ref({})
// 获取接口参数
const getBody = (e: any) => {
  dataBody.value = e;
}
const emit = defineEmits(['onCancel'])
const onCancel = () => {
  emit('onCancel')
}
</script>

<style scoped lang="less"></style>