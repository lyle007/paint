<template>
  <div>
    <splitpane class="page" ratio="1/4">
      <template #one>
        <div class="left">
          <orgtree @changeCheck="changeCheck" :checkedKeys="params.org_ids" :disabled="props.readonly" />
        </div>
      </template>
      <template #two>
        <a-input-search v-model:value="params.distribute_search" placeholder="账户/姓名/所属组" @search="onSearch" />
        <a-table :dataSource="tableData.dataSource" rowKey="id"
          :row-selection="{ selectedRowKeys: selectedRowKeys, onChange: onSelectChange, getCheckboxProps: getCheckboxProps }"
          :columns="tableData.columns" :pagination="false">
        </a-table>
        <a-pagination @change="getlist" show-size-changer v-model:current="params.page" v-model:pageSize="params.rows"
          :total="count" />
      </template>
    </splitpane>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive, nextTick, watch } from 'vue';
import orgtree from '../orgtree/index.vue';
import splitpane from '@/components/splitpane/index.vue';

import { getUserData, members } from './api';

const props = defineProps({
  memberUrl: {
    type: String,
    default() {
      return ''
    }
  },
  readonly: {
    type: Boolean,
    default() {
      return false
    }
  },
  rowData: Object
})
const tableData = reactive({
  dataSource: [],
  columns: [
    {
      title: '',
      dataIndex: 'check',
      key: 'check',
      align: 'center'
    },
    {
      title: '账号',
      dataIndex: 'username',
      key: 'username',
      align: 'center'
    },
    {
      title: '姓名',
      dataIndex: 'name',
      key: 'name',
      align: 'center'
    },
    {
      title: '所属组',
      dataIndex: 'org_name',
      key: 'org_name',
      align: 'center'
    },
    {
      title: '设备数量',
      dataIndex: 'device_num',
      key: 'device_num',
      align: 'center'
    },
  ]
})
watch(() => props.rowData, async (value: any) => {
  if (value) {
    await nextTick()
    membersParms.id = value.id,
    membersParms.cul_bind = value.cul_bind;
    getMember()
  }
}, { immediate: true })
const count = ref(0)
const selectedRowKeys = ref([])
const params = reactive({
  page: 1,
  rows: 10,
  distribute_search: "",
  search: "",
  org_ids: [],
  user_tag_ids: [],
  selected_ids: [],
  location_id: "",
  selected_type: "selected",
  device_tag_ids: [],
  brand_model: [],
  ownership: [],
  username: "mtadn",
  platform: "Android/HarmonyOS,iOS",
  control_level: ""
})
const emit = defineEmits(['getBody'])
function onSearch() {
  getlist();
}
// 获取选中的值
const changeCheck = (e: any) => {
  params.org_ids = e;
  gBody.org_ids = e;
  getlist();
}
// 获取已人员
const membersParms = reactive({
  cul_bind: '',
  id: ''
})
// 取已经分配的组织用户
const user_id_list = ref<any>([]); // 组织分配的人；

const getMember = () => {
  members(props.memberUrl, membersParms).then((res) => {
    params.selected_ids = res.data.user_id_list;
    user_id_list.value = res.data.user_id_list;
    selectedRowKeys.value = res.data.user_id_list;
    gBody.user_ids = res.data.user_id_list;
    getlist()
  })
}
// 获取人员列表
const getlist = () => {
  getUserData(params).then(async (res: any) => {
    if (res.data.count != 0) {
      tableData.dataSource = res.data.result;
      await nextTick()
      gBody.id = membersParms.id;
      emit('getBody', gBody)
      count.value = res.data.count;
    } else {
      selectedRowKeys.value = [];
      tableData.dataSource = [];
    }
  })
}
const gBody = reactive({
  ids: [],
  id: '',
  msg_id: null,
  org_ids: [],
  org_del_ids: [],
  type: "user",
  auto_download: false,
  orgs: [],
  user_ids: [
    
  ],
  user_tag_ids: [],
  device_ids: [],
  device_tag_ids: [],
  ownership: [],
  brand_model: [],
  cancel_user_ids: [],
  location_id: "",
  vpp_id: "",
  serial_ids: []
})
const onSelectChange = (a: any) => {
  selectedRowKeys.value = a;
  gBody.user_ids = a;
  emit('getBody', gBody)
}
const getCheckboxProps = () => {
  return {
    disabled: props.readonly
  }
}
</script>

<style scoped lang="less"></style>