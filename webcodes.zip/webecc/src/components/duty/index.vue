<template>
  <div>
    <a-modal :visible="props.visible" title="发送" width="80%" class="distribute" @cancel="onCancel" @ok="ok">
      <a-tabs v-model:activeKey="activeKey">
        <a-tab-pane key="user" tab="按用户">
          <user @change="change" v-if="props.visible"></user>
        </a-tab-pane>
      </a-tabs>
    </a-modal>
  </div>
</template>

<script setup lang="ts">
import { ref } from 'vue';
import user from './user.vue'
const activeKey = ref('user')

const props = defineProps({
  visible: {
    type: Boolean,
    default() {
      return false
    }
  }
})
const emit = defineEmits(['cancel', 'change'])
const keyArry = ref([])
const change = (e: any) => {
  keyArry.value = e
}
// 退出
const onCancel = () => {
  emit('cancel')
}
// 确定
const ok = () => {
  emit('cancel');
  emit('change', keyArry.value);
}
</script>

<style scoped lang="less"></style>