<template>
  <div>
    <splitpane class="page" ratio="1/4">

      <template #one>
        <div class="left">
          <orgtree @changeCheck="changeCheck" />
        </div>
      </template>
      <template #two>
        <div class="search-box">
          <a-input-search v-model:value="searchData.search" placeholder="支持多关键字搜索（账号，姓名所属组）" style="width: 400px"
            @search="onSearch()" />
        </div>
        <a-table :dataSource="tableData.dutyDataList" :columns="tableData.columns" :pagination="false" rowKey="username"
          :row-selection="{ selectedRowKeys: selectedRowKeys, onChange: onSelectChange }"
          :row-class-name="(_record: any, index: number) => (index % 2 === 1 ? 'table-striped' : null)">
        </a-table>
        <a-pagination v-model:current="searchData.page" :total="count" show-less-items @change="getlistchange" size="small"/>
      </template>
    </splitpane>

  </div>
</template>

<script setup lang="ts">
import { reactive, ref, onMounted } from 'vue';
import { getUserData } from '@/components/distribute/api';
import splitpane from '@/components/splitpane/index.vue';
import orgtree from '../orgtree/index.vue';
let searchData = reactive({
  page: 1,
  rows: 10,
  distribute_search: "",
  search: "",
  org_ids: [],
  user_tag_ids: [],
  selected_ids: <any>[],
  location_id: "",
  device_tag_ids: [],
  brand_model: [],
  ownership: [],
  username: "mtadn",
  platform: "ANDROID",
  control_level: ""
})
const tableData = reactive({
  columns: [
    {
      title: '账号',
      dataIndex: 'username',
      key: 'username',
      align: 'center'
    },
    {
      title: '姓名',
      dataIndex: 'name',
      key: 'name',
      align: 'center'
    },
    {
      title: '所属组',
      dataIndex: 'org_name',
      key: 'org_name',
      align: 'center'
    },
  ],
  dutyDataList: []
})
const emit = defineEmits(['change'])
const selectedRowKeys = ref([])
const onSelectChange = (e: any, objitem: any) => {
  selectedRowKeys.value = e;
  searchData.selected_ids = searchData.selected_ids.concat(objitem.map((item: any) => item.id));
  searchData.selected_ids = [...new Set(searchData.selected_ids)]
  console.log(searchData.selected_ids)
  emit('change', e)
}
const count = ref(0)
onMounted(() => {
  getlist()
})
const getlist = async () => {
  searchData.username = JSON.parse(sessionStorage.getItem('user') || '').username
  const { data } = await getUserData(searchData)
  tableData.dutyDataList = data.result;
  const ids = data.result.filter((item: any) => searchData.selected_ids.includes(item.id));
  selectedRowKeys.value = ids.map((item: any) => item.username);
  count.value = data.count;
}
const onSearch = () => {
  searchData.page = 1;
  
  getlist()
}
const changeCheck = (e: any) => {
  searchData.org_ids = e;
  getlist()
}
const getlistchange = (page: number, size: number) => {
  searchData.page = page; 
  searchData.rows = size;
  getlist()
}
</script>

<style scoped lang="less">
.search-box {
  padding: 10px 0;
  text-align: right;
}
:deep(.ant-modal-body) {
  padding: 0 20px;
}
</style>