import { type App } from 'vue';
import Empty from './index.vue';
/**
 * 空状态
 */
export default {
    install: (app: App): void => {
        app.component('empty', Empty);
    },
};
