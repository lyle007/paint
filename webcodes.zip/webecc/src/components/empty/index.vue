<template>
  <div class="empty-box">
    <div class="empty-box-images">
      <img v-if="type == 'list'" src="@/assets/bgimages/empty.png" alt="">
      <img v-if="type == 'video'" src="@/assets/bgimages/videobg.png" alt="">
      <div>暂无数据</div>
    </div>
  </div>
</template>
  
<script setup lang="ts">

withDefaults(
  defineProps<{
    type?: string;
  }>(),
  {
    type: 'list',
  }
);
</script>
  
<style scoped lang="less">
.empty-box {
  width: 100%;
  height: 100%;
  display: flex;
  align-items: center;

  .empty-box-images {
    width: 200px;
    margin: 0 auto;
    text-align: center;

    img {
      width: 100%;
    }

  }
}
</style>