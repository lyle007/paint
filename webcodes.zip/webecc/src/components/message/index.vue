<template>
  <div class="message-bg" :class="{ isbig: !isfull }">
    <!-- 群列表 -->
    <div :class="['message-left', flag ? 'is-left' : 'not-left']">
      <div class="left-h">
        <a-input placeholder="搜索">
          <template #prefix>
            <search-outlined />
          </template>
        </a-input>
        <plus-circle-outlined class="add" />
      </div>
      <div class="left-c">
        <div class="groups" v-for="(item, index) in group" :key="item['groupID']" @click="groupClick(item, index)"
          :class="{ active: item['groupID'] == groupObj['groupID'] }">
          <!-- <img v-if="item['groupIcon']" :src="item['groupIcon']" alt=""> -->
          <!-- v-if="!item['groupIcon']" -->
          <img  src="@/assets/bgimages/group.png" alt="">
          <div class="titles">
            <div class="mt-text-one">{{ item['groupName'] }}</div>
            <div class="mt-text-one"></div>
          </div>
          <a-badge :count="item['badge']" class="badge" v-if="item.groupID != groupObj.groupID" />
        </div>
      </div>
      <div :class="['caret-left', flag ? 'is-caret-left' : 'not-caret-left']" @click="toLeft()">
        <caret-left-outlined />
      </div>
    </div>
    <!-- 消息内容 -->
    <div :class="['message-right', flag ? 'is-right' : 'not-right']">
      <header class="head">
        <div class="head-l mt-text-one">
          {{ groupObj.groupName }}
        </div>
        <div class="head-r">
          <svg-icon name="mt-big" width="20" height="20" fill="#272636" class="ms-min" @click="scroolBig()"
            v-if="isfull"></svg-icon>
          <svg-icon name="fulls_mute" width="20" height="20" fill="#272636" class="ms-min" @click="scroolBig()"
            v-if="!isfull"></svg-icon>
          <svg-icon name="more" width="20" height="20" fill="#272636" class="more" @click="mores()"></svg-icon>
        </div>
      </header>
      <!-- 消息体 -->
      <div class="ms-contents">
        <div :class="['ms-content-box', flagDown ? 'is-content' : 'not-content']">
          <div :class="['ms-content']">
            <template v-for="item in messageData">
              <div class="ms-item" v-if="!item['myself'] && messageFilter(item)">
                <div class="ms-io" v-if="messageFilter(item)">
                  <img src="@/assets/bgimages/person.png" alt="">
                </div>
                <div class="rights" v-if="messageFilter(item)">
                  <div class="ms-name">{{ showName(item) }}</div>
                  <div class="ms-body" v-if="messageFilter(item)['message']['body']">
                    {{ messageFilter(item)['message']['body'] }}
                  </div>
                  <div class="ms-body" v-if="!messageFilter(item)['message']['body']">
                    <img :src="`data:image/jpeg;${messageFilter(item)['message']['thumbbin']}`" alt="">
                  </div>
                </div>
              </div>
              <div class="ms-item-right" v-if="item['myself']">
                <div class="ms-io" v-if="messageFilter(item)">
                  <img src="@/assets/bgimages/person.png" alt="">
                </div>
                <div class="rights" v-if="messageFilter(item)">
                  <div class="ms-name" style="text-align: right;">ECC消息助手</div>
                  <div class="ms-body" style="float: right;">
                    {{ messageFilter(item)['message']['body'] }}
                  </div>
                </div>
              </div>
            </template>
            <div ref="child" v-show="'false'"></div>
            <div :class="['caret-up', flagDown ? 'is-caret-up' : 'not-caret-up']">
              <caret-up-outlined @click="toDown()" />
            </div>
          </div>
        </div>

        <!-- <div :class="['sendmess', flagDown ? 'is-down' : 'not-down']">
          <div class="sendmess-head">

            <div :class="['caret-down', flagDown ? 'is-caret-down' : 'not-caret-down']" @click="toDown()">
              <caret-down-outlined />
            </div>
          </div>
          <textarea ref="textarea" v-model="sendMeeage" placeholder="" :rows="2"> </textarea>
          <a-button size="small" type="primary" :class="['send', , flagDown ? 'is-send' : 'not-send']"
            @click="send()">发送</a-button>
        </div> -->
      </div>
      <div :class="['caret-right', flag ? 'is-caret-right' : 'not-caret-right']" @click="toLeft()">
        <caret-right-outlined />
      </div>
    </div>

    <a-drawer v-model:visible="visible" :closable="false" :get-container="false" :style="{ position: 'absolute' }"
      placement="right">
      <div class="drawer-d">
        <p class="title">群聊名称:</p>
        <p class="drawer-name">{{ groupObj.groupName }}</p>
      </div>
      <div class="drawer-d">
        <p class="title">群公告:</p>
        <p class="drawer-name">{{ groupObj.groupBulletin }}</p>
      </div>
      <div class="drawer-d">
        <p class="title">群成员:</p>
        <div class="userlist-item" v-for="item in userList">{{ item['name'] }}</div>
      </div>

    </a-drawer>
  </div>
  <div :class="{ 'mes-bg': !isfull }"></div>
</template>
  
<script setup lang="ts">
import { onMounted, ref, watch, computed, nextTick } from 'vue'
import { message } from 'ant-design-vue';
import { SearchOutlined, PlusCircleOutlined, CaretLeftOutlined, CaretRightOutlined, CaretUpOutlined } from '@ant-design/icons-vue'
import { DOUDOU } from '@/config/config'
import { loginMessageToken, getgrouplist, getgroupd, getMembers } from '@/api/message/index';
import { storeToRefs } from 'pinia';
import { useCounterStore } from "../../store/index";
import cloneDeep from 'clone-deep';



const useStore = useCounterStore();
const { messages } = storeToRefs(useStore); // 聊天消息
watch(messages, (newValue: any, oldValue: any) => {
  if (newValue !== oldValue) {
    messageData.value.push(newValue);
    group.value.forEach((element: any) => {
      if (element.groupID == newValue['receTargetID']) {
        if (Array.isArray(element['mesCount'])) {
          element['mesCount'].push(newValue);
          element['badge']++
        }
      }
    });

    nextTick(() => {
      child.value.scrollIntoView(); // 关键代码
      const unshift = group.value.find((items: any) => items.groupID == newValue['receTargetID']);
      const findIndex = group.value.findIndex((items: any) => items.groupID == newValue['receTargetID']);
      group.value.splice(findIndex, 1)
      group.value.unshift(unshift);
    });
  }
});
// 群消息过滤
const messageFilter = computed(() => {
  return function (item: any) {
    if (item['receTargetID'] == groupObj.value.groupID) {
      return item
    } else {

      return false
    }
  }
})
// 人员名称展示
const showName = computed(() => {
  return function (item: any) {
    if (item['receTargetID'] == groupObj.value.groupID) {
      const peolpe = userList.value.find((child: any) => item.sendUserID == child.userID)
      return peolpe.name
    } else {
      return false
    }
  }
})

let group = ref<any>([]); // 群列表
let activeN = ref(0)
let groupObj = ref({
  groupID: "",
  groupName: "我的额",
  groupIcon: "",
  groupBulletin: "群公告",
  groupLevel: 1,
  relatedEnterpriseID: 0,
  initGroupMembers: []
})
let visible = ref(false);

// let sendMeeage = ref('');
let userList = ref<any>([])
let messageData = ref<any>([])  // 监听到的消息体
watch(messageData, () => {
  nextTick(() => {
    child.value.scrollIntoView(); // 关键代码
  });
}, { deep: true })
const child = ref();

const isfull = ref(true);

onMounted(async () => {
  const result: any = await loginMessageToken();
  if (result['code'] == 0) {
    sessionStorage.setItem('dou_token', result.result.access_token);
    // 获取群列表
    getGroupLists()
  } else {
    message.warn('消息模块登录失败，请联系管理人员！')
  }
})
// 群列表
const getGroupLists = () => {
  getgrouplist({ openID: DOUDOU.appID }).then((res: any) => {
    if (res.code == 0) {
      group.value = res.result;
      group.value.forEach((elment: any) => {
        elment['mesCount'] = []
        elment['badge'] = 0
      });
      groupD(group.value[0]['groupID']);
      getMemberList(group.value[0]['groupID'])
    }
  })
}
// 获取群详细信息
const groupD = (id: string) => {
  getgroupd(id).then((res: any) => {
    if (res.code == 0) {
      groupObj.value = res.result;
    }
  })
}
// 群的信息信息
const mores = () => {
  visible.value = true;
}
// 获取群成员列表
const getMemberList = (groupid: string) => {
  const params = {
    lang: 'zh_CN',
    pageNo: 1
  }
  getMembers(groupid, params).then((res: any) => {
    if (res.code == 0) {
      userList.value = res.result.userList;
    }
  })
}
// 发消息
// const send = async () => {
//   if (!sendMeeage.value) {
//     return
//   }
//   const data = {
//     receTargetID: groupObj.value.groupID,
//     messageType: 2,
//     message: sendMeeage.value,
//     chatScene: 'group',
//     accountType: ''
//   }
//   const data2 = {
//     message: {
//       body: sendMeeage.value
//     },
//     receTargetID: groupObj.value.groupID,
//     myself: true
//   }
//   const result = await sendmessgae(data);
//   if (result) {
//     messageData.value.push(data2)
//     sendMeeage.value = '';
//     group.value.forEach((element: any) => {
//       if (element.groupID == groupObj.value.groupID) {
//         if (Array.isArray(element['mesCount'])) {
//           element['mesCount'].push(data2);
//         }
//       }
//     });
//   }
// }
// 左侧展开
const flag = ref(false)
const toLeft = () => {
  flag.value = !flag.value
}
// 底部展开
const flagDown = ref(false)
const toDown = () => {
  flagDown.value = !flagDown.value
}

// const textarea = ref()
const groupClick = (item: any, index: number) => {
  activeN.value = index;
  groupD(item['groupID']);
  getMemberList(item['groupID']);
  item['badge'] = 0;
  messageData.value = cloneDeep(item.mesCount);
  nextTick(() => {
    child.value.scrollIntoView(); // 关键代码
  });
}
// 放大缩小
const scroolBig = () => {
  isfull.value = !isfull.value
}
</script>
  
<style scoped lang="less">
p {
  margin: none;
}

.isbig {
  width: 900px;
  height: 700px !important;
  position: fixed !important;
  left: 50% !important;
  top: 50% !important;
  transform: translate(-50%, -50%);
  z-index: 99999;
}

.mes-bg {
  position: fixed;
  top: 0;
  left: 0;
  width: 100vw;
  height: 100vh;
  background-color: rgba(0, 0, 0, 0.3);
  z-index: 99998;
}

.message-bg {
  background: #FEFFFF;
  box-shadow: 0px 2px 5px 0px rgba(0, 0, 0, 0.05);
  border-radius: 2px 0px 0px 2px;
  height: 100%;
  display: flex;
  position: relative;
  overflow: hidden;

  .message-left {
    overflow: hidden;
    height: 100%;
    padding: 5px;
    border-right: 1px solid #E8E8E8;
    position: relative;

    .left-h {
      height: 50px;
      line-height: 50px;
      padding: 0 5px;
      display: flex;
      justify-content: space-between;
      align-items: center;

      .add {
        font-size: 20px;
        margin-left: 12px;
        color: #999;
      }
    }

    .left-c {
      height: calc(100% - 50px);
      overflow-y: scroll;
    }

    .left-c::-webkit-scrollbar {
      display: none;
    }

    .groups {
      padding: 8px 5px;
      background: #fff;
      display: flex;
      font-size: 12px;
      position: relative;

      img {
        width: 36px;
        height: 36px;
        margin-right: 10px;
      }
    }

    .titles {
      width: calc(100% - 36px);
    }

    .caret-left {
      position: absolute;
      top: 50%;
      right: 4px;
    }
  }

  .is-left {
    width: 0px;
    padding: 0px;
    transition: all 0.5s;
  }

  .not-left {
    width: 190px;
    transition: all 0.5s;
  }

  .is-caret-left {
    width: 0px;
    overflow: hidden;
    transition: all 0.5s;
  }

  .not-caret-left {
    width: 10px;
    overflow: hidden;
    transition: all 0.5s;
  }

  .message-right {
    position: relative;
    height: 100%;

    .head {
      background: #F7F7F7;
      border-radius: 0px 2px 0px 0px;
      height: 30px;
      display: flex;

      .head-l {
        width: calc(100% - 150px);
        padding-left: 24px;
        line-height: 30px;
        font-size: 14px;
      }

      .head-r {
        width: 150px;
        height: 100%;
        position: relative;

        .more {
          position: absolute;
          right: 10px;
          bottom: 5px;
        }
      }
    }


  }

  .is-right {
    width: 100%;
    transition: all 0.5s;
  }

  .not-right {
    width: calc(100% - 190px);
    transition: all 0.5s;
  }

  .caret-right {
    position: absolute;
    top: 50%;
    left: 0px;
  }

  .is-caret-right {
    width: 10px;
    overflow: hidden;
    transition: all 0.5s;
  }

  .not-caret-right {
    width: 0px;
    overflow: hidden;
    transition: all 0.5s;
  }
}

.active {
  background-color: #E5EFFD !important;
}

.drawer-d {
  margin-bottom: 10px;

  .userlist-item {
    width: 100%;
    padding: 5px 0px;
  }

  .title {
    margin-bottom: 10px;
  }

  .drawer-name {
    color: #999;
  }
}

.ms-content-box {
  height: 100%;
  position: relative;
  overflow: hidden !important;
  overflow-y: auto !important;
  // max-height: 300px;
}

.ms-contents {
  height: calc(100% - 30px);

  .sendmess {
    height: 110px;
    position: relative;
    // overflow: hidden;

    .sendmess-head {
      border-top: 1px solid #DEDEDE;
      font-size: 20px;
      position: relative;

      span {
        margin-left: 20px;
      }

      .caret-down {
        position: absolute;
        right: 10px;
        top: 0px;
        font-size: 14px;
      }
    }

    .send {
      position: absolute;
      right: 10px;
      bottom: 10px;

    }

    .is-send {
      height: 0px;
      border: none;
      transition: all 0.3s;
    }

    .is-send {
      transition: all 0.3s;
    }
  }

  .is-down {
    height: 0px;
    transition: all 0.5s;
  }

  .not-down {
    height: 110px;
    transition: all 0.5s;
  }

  textarea {
    height: 40px;
    padding: 0px 10px;
    resize: none;
  }

  .ms-content {
    max-height: calc(100% - 300px);

    .ms-item {
      padding: 14px;
      width: 60%;
      display: flex;

      .ms-io {
        width: 34px;
        height: 34px;
        margin: 4px;
        // background-color: red;
        border-radius: 4px;

        img {
          width: 34px;
          height: 34px;
        }
      }

      .rights {
        width: calc(100% - 42px);
      }
    }

    .ms-body {
      background-color: #F7F7F7;
      padding: 14px;
      border-radius: 5px;
      display: inline-block;
    }

    .ms-item-right {
      padding: 14px;
      width: 60%;
      display: flex;
      flex-direction: row-reverse;
      float: right;

      .ms-io {
        width: 34px;
        height: 34px;
        margin: 4px;
        border-radius: 4px;

        img {
          width: 34px;
          height: 34px;
        }
      }
    }

    .caret-up {
      position: absolute;
      right: 10px;
      bottom: 0px;
      font-size: 14px;
    }
  }

  .is-content {
    height: 100%;
    transition: all 0.5s;
  }

  .not-content {
    height: calc(100% - 30px);
    transition: all 0.5s;
  }

}

.is-caret-up {
  height: 20px;
  overflow: hidden;
  transition: all 0.5s;
}

.not-caret-up {
  height: 0px;
  overflow: hidden;
  transition: all 0.5s;

}

.is-caret-down {
  height: 0px;
  overflow: hidden;
  transition: all 0.5s;
}

.not-caret-down {
  height: 20px;
  overflow: hidden;
  transition: all 0.5s;
}

textarea {
  border: none;
  outline: 0;
  width: 100%;
  padding: 10px;
}

.ms-content::-webkit-scrollbar {
  width: 10px;
}

.ms-content::-webkit-scrollbar-thumb {
  background-color: #949292;
  border-radius: 4px;
}

.badge {
  position: absolute;
  left: 30px;
  top: 0px;
  font-size: 10px;
}

.ms-min {
  position: absolute;
  right: 40px;
  bottom: 5px;
}
</style>