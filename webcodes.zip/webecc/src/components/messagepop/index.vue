<template>
  <div>
    <a-modal class="warning-box" v-model:visible="visiblePop" :footer="null">
      <template #title>
        <div class="warning-title">
          <div @click="goList('fault')">
            <svg-icon name="waring-duty" width="30" height="30"></svg-icon>
            <p>故障消息</p>
            <a-badge class="badge" :count="count.fault" />
          </div>
          <div @click="goList('cloudEye')">
            <svg-icon name="waring-event" width="30" height="30"></svg-icon>
            <p>CloudEye</p>
            <a-badge class="badge" :count="count.cloudEye" />
          </div>
          <div @click="goList('message')">
            <svg-icon name="waring-message" width="30" height="30"></svg-icon>
            <p>事件消息</p>
            <a-badge class="badge" :count="count.message" />
          </div>
        </div>
      </template>
      <!-- 事件消息 -->
      <div v-if="showModel == 'message'">
        <div class="message-box">
          <h3>{{ warningMessage.title }}</h3>
          <div v-html="warningMessage.content"></div>
        </div>
      </div>
      <!-- 故障 -->
      <div v-if="showModel == 'fault'" class="message-box">
        <div class="message" v-if="!(faultData.incident_message && faultData.incident_message.message_data)">
          <div class="message-row">
            <div class="message-item mt-text-one">
              操作人员:
              {{
                faultData.handler_person
              }}
            </div>
            <div class="message-item mt-text-one">
              操作部门:
              {{
                faultData.handler_department
              }}
            </div>
          </div>
          <div class="message-row">
            <div class="message-item mt-text-one">
              事件等级:
              {{
                faultData.incident_level
              }}
            </div>
            <div class="message-item mt-text-one">
              事件原因:
              {{
                faultData.incident_reason
              }}
            </div>
          </div>
          <div class="message-row">
            <div class="message-item mt-text-one">
              是否停止:
              {{
                faultData.is_stopped
              }}
            </div>
            <div class="message-item mt-text-one">
              事件状态:
              {{
                faultData.status
              }}
            </div>
          </div>
          <div class="message-row">
            <div class="message-item mt-text-one">
              发送部门:
              {{
                faultData.send_department
              }}
            </div>
          </div>
          <div class="message-row">
            <div class="message-item mt-text-one">
              {{
                faultData.update_time
              }}
            </div>
          </div>
        </div>
        <!-- 有消息推送展示数据 -->
        <!-- v-if="item.incident_message&&item.incident_message.message_data" -->
        <div class="message" v-if="faultData.incident_message && faultData.incident_message.message_data">
          <!-- 新建 + 追加 -->
          <div v-if="faultData.incident_message.message_data.status != 3">
            <div style="text-align: left;">
              故障ID： {{ faultData.incident_message.message_data.incident_number }}
            </div>
            <a-row class="message-row">
              <a-col :span="24" class="message-col mt-text-one">
                {{ faultData.incident_message.message_data.summary }}
              </a-col>
            </a-row>

            <div class="line-solid"></div>

            <a-row class="message-row" v-if="faultData.incident_message.message_data.time_location">
              <a-col :span="24" class="message-col mt-text-one">
                时间/地点： {{ faultData.incident_message.message_data.time_location }}
              </a-col>
            </a-row>
            <a-row class="message-row" v-if="faultData.incident_message.message_data.incident_time">
              <a-col :span="24" class="message-col mt-text-one">
                故障时间： {{ faultData.incident_message.message_data.incident_time }}
              </a-col>
            </a-row>
            <a-row class="message-row" v-if="faultData.incident_message.message_data.network">
              <a-col :span="24" class="message-col mt-text-one">
                网络/线路： {{ faultData.incident_message.message_data.network }}
              </a-col>
            </a-row>
            <a-row class="message-row" v-if="faultData.incident_message.message_data.product">
              <a-col :span="24" class="message-col mt-text-one">
                产品/软件： {{ faultData.incident_message.message_data.product }}
              </a-col>
            </a-row>
            <a-row class="message-row" v-if="faultData.incident_message.message_data.device_location">
              <a-col :span="24" class="message-col mt-text-one">
                故障设备: {{ faultData.incident_message.message_data.device_location }}
              </a-col>
            </a-row>
            <a-row class="message-row" v-if="faultData.incident_message.message_data.incident_device">
              <a-col :span="24" class="message-col mt-text-one">
                设备地点： {{ faultData.incident_message.message_data.incident_device }}
              </a-col>
            </a-row>
            <a-row class="message-row" v-if="faultData.incident_message.message_data.resource_pool">
              <a-col :span="24" class="message-col mt-text-one">
                资源池 {{ faultData.incident_message.message_data.resource_pool }}
              </a-col>
            </a-row>

            <div class="line-dashed"></div>

            <a-row class="message-row">
              <a-col :span="24" class="message-col mt-text-one">
                故障现象： {{ faultData.incident_message.message_data.phenomenon }}
              </a-col>
            </a-row>
            <a-row class="message-row" v-if="faultData.incident_message.message_data.error_code">
              <a-col :span="24" class="message-col mt-text-one">
                故障码: {{ faultData.incident_message.message_data.error_code }}
              </a-col>
            </a-row>
            <a-row class="message-row" v-if="faultData.incident_message.message_data.error">
              <a-col :span="24" class="message-col mt-text-one">
                故障报错: {{ faultData.incident_message.message_data.error }}
              </a-col>
            </a-row>
            <div class="line-dashed"></div>

            <a-row class="message-row">
              <a-col :span="24" class="message-col mt-text-one">
                故障影响: {{ faultData.incident_message.message_data.effect }}
              </a-col>
            </a-row>
            <a-row class="message-row" v-if="faultData.incident_message.message_data.reason">
              <a-col :span="24" class="message-col mt-text-one">
                故障原因: {{ faultData.incident_message.message_data.reason }}
              </a-col>
            </a-row>
            <a-row class="message-row">
              <a-col :span="24" class="message-col mt-text-one">
                备注: {{ faultData.incident_message.message_data.remark }}
              </a-col>
            </a-row>
            <a-row class="message-row">
              <a-col :span="24" class="message-col mt-text-one">
                ({{ faultData.incident_message.message_data.datetime }})
              </a-col>
            </a-row>
          </div>
          <!-- 已恢复 -->
          <div v-if="faultData.incident_message.message_data.status == 3">
            <div style="text-align: left;">
              故障ID： {{ faultData.incident_message.message_data.incident_number }}（故障恢复）
            </div>
            <a-row class="message-row">
              <a-col :span="24" class="message-col mt-text-one">
                {{ faultData.incident_message.message_data.summary }}
              </a-col>
            </a-row>
            <a-row class="message-row" v-if="faultData.incident_message.message_data.network">
              <a-col :span="24" class="message-col mt-text-one">
                网络/线路： {{ faultData.incident_message.message_data.network }}
              </a-col>
            </a-row>
            <a-row class="message-row" v-if="faultData.incident_message.message_data.product">
              <a-col :span="24" class="message-col mt-text-one">
                产品/软件： {{ faultData.incident_message.message_data.product }}
              </a-col>
            </a-row>
            <a-row class="message-row" v-if="faultData.incident_message.message_data.product">
              <a-col :span="24" class="message-col mt-text-one">
                故障持续时间：{{ faultData.incident_message.message_data.coast }}
              </a-col>
            </a-row>
            <div class="line-dashed"></div>
            <a-row class="message-row">
              <a-col :span="24" class="message-col mt-text-one">
                故障影响: {{ faultData.incident_message.message_data.effect }}
              </a-col>
            </a-row>
            <a-row class="message-row" v-if="faultData.incident_message.message_data.reason">
              <a-col :span="24" class="message-col mt-text-one">
                故障原因: {{ faultData.incident_message.message_data.reason }}
              </a-col>
            </a-row>
            <a-row class="message-row">
              <a-col :span="24" class="message-col mt-text-one">
                ({{ faultData.incident_message.message_data.datetime }})
              </a-col>
            </a-row>
          </div>
        </div>
        <div style="text-align: center;"><a-button type="primary" @click="goFault(faultData)">去详情</a-button></div>
      </div>
      <!-- CloudEye -->
      <div v-if="showModel == 'cloudEye'" class="message-box">
        <div class="message">
          <a-row>
            <a-col :span="24">事件名： {{ cloudEyeData.event_name }} </a-col>
          </a-row>
          <a-row>
            <a-col :span="12">等级： {{ cloudEyeData.grade }} </a-col>
            <a-col :span="12">处理人 {{ cloudEyeData.who_do }} </a-col>
          </a-row>
          <a-row>
            <a-col :span="12">状态： {{ cloudEyeData.status }} </a-col>
            <a-col :span="12">使用类型： {{ cloudEyeData.use_type }} </a-col>
          </a-row>
          <a-row>
            <a-col :span="12">报警时间： {{ cloudEyeData.create_time }} </a-col>
          </a-row>
        </div>
        <div style="text-align: center;"><a-button type="primary" @click="gocloudEye(cloudEyeData)">去详情</a-button></div>
      </div>
    </a-modal>
  </div>
</template>

<script setup lang="ts">
import { ref, watch, reactive } from 'vue'
import { storeToRefs } from 'pinia';
import { useRouter } from 'vue-router';
import { useCounterStore } from "@/store/index";
import { newReady } from '@/api/messagemanage/index';
const useStore = useCounterStore();
const router = useRouter();
const { faultList, messageWarning, eventList } = storeToRefs(useStore);
const visiblePop = ref(false);

const showModel = ref('message');
const count = reactive({
  message: 0,
  fault: 0,
  cloudEye: 0,
})
// 监听消息数据弹窗
const warningMessage = ref({
  title: '',
  content: ''
})
watch(messageWarning, async (newValue: any, oldValue: any) => {

  if (window.location.hash.includes('login')) {
    return
  }
  if (newValue.id !== oldValue.id) {
    console.log('消息messageWarning', newValue);
    visiblePop.value = true;
    showModel.value = 'message';
    count.message++;
    warningMessage.value = newValue;
    // 自动已读
    newReady(newValue.id)
  }
});

const cloudEyeData = ref<any>({})
// 监听事件信息，弹出警告弹窗
watch(eventList, async (newValue: any, oldValue: any) => {
  if (window.location.hash.includes('login')) {
    return
  }
  return
  if (newValue !== oldValue) {
    console.log('消息eventList', newValue);
    visiblePop.value = true;
    showModel.value = 'cloudEye';
    if (Array.isArray(newValue)) {
      count.cloudEye += newValue.length;
      cloudEyeData.value = newValue[newValue.length - 1];
    } else {
      count.cloudEye++;
      cloudEyeData.value = newValue;
    }
  }

});

const faultData = ref<any>({})
// 监听故障信息，弹出警告弹窗
watch(faultList, async (newValue: any, oldValue: any) => {
  if (window.location.hash.includes('login')) {
    return
  }
  return
  if (newValue !== oldValue) {
    console.log('消息faultList', newValue);
    visiblePop.value = true;
    showModel.value = 'fault';
    if (Array.isArray(newValue)) {
      count.fault += newValue.length;
      faultData.value = newValue[newValue.length - 1]
    } else {
      count.fault++;
      faultData.value = newValue
    }
  }
});
watch(visiblePop, (value: any) => {
  if (!value) {
    count.message = 0;
    count.cloudEye = 0;
    count.fault = 0;
  }
})

const goList = (type: string) => {
  if (type == 'fault') {
    router.push({
      path: '/fault/faultList'
    })
  } else if (type == 'cloudEye') {
    router.push({
      path: '/eventmanage/cloudeye'
    })
  } else if (type == 'message') {
    router.push({
      path: '/messagemanage/events'
    })
  }
  visiblePop.value = false;
}
const goFault = (item: any) => {
  router.push({
    path: '/fault/faultdetails',
    query: {
      id: item.incident_id
    }
  })
  visiblePop.value = false;
}
const gocloudEye = (item: any) => {
  router.push({
    path: '/eventmanage/eventdetails',
    query: {
      id: item.event_id
    }
  })
  visiblePop.value = false;
}
</script>

<style scoped lang="less">
.warning-title {
  display: flex;
  justify-content: space-around;

  div {
    display: flex;
    flex-direction: column;
    align-items: center;
    position: relative;
    font-size: 12px;

    .badge {
      position: absolute;
      top: -8px;
      right: 0px;
    }
  }
}

.message-box {
  height: 40vh;
  overflow-y: auto;

  h3 {
    text-align: center;
  }
}

.message {
  height: calc(100% - 40px);
  overflow-y: auto;
  font-size: 12px;
  padding: 10px;

  .message-row {
    width: 100%;
    height: 15%;
    text-align: left;
    display: flex;
    justify-content: space-between;

    .message-item {
      width: 100%;
      height: 100%;
      padding: 0px 10px 0px 0px;
    }
  }
}
.line-solid {
  border: 1px solid #ccc;
  margin: 5px 0;
  width: 60%;
}

.line-dashed {
  border: 1px dashed #ccc;
  margin: 5px 0;
  width: 60%;
}
</style>