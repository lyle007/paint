import axiosInstance from "@/api/http";


/**
 * @auth phy
 * 说明：组织机构树
 */

export function findTree(data: any) {
  const user = JSON.parse(sessionStorage.getItem('user') || '');
  if (user.role == 'ADMIN') {
    return axiosInstance({
      url: `/sap/api/v1.0/admin/org/find_btree`,
      method: 'post',
      data: data
    })
  } else {
    return axiosInstance({
      url: `/ecs/api/v1.0/common/forward_meap`,
      method: 'post',
      data: {
        url: "/sap/api/v1.0/admin/org/find_btree",
        body_param: JSON.stringify(data)
      }
    })
  }

}
