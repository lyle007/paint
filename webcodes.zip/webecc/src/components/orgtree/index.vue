<template>
  <div class="tree-box">
    <a-tree :tree-data="treeData" :checkStrictly="true" :fieldNames="fieldNames" checkable @check="check"
      v-model:checkedKeys="checkedKeys" v-model:expandedKeys="expandedKeys" @rightClick="rightClick">
      <template #title="{ name }">
        <a-dropdown :trigger="['contextmenu']">
          <span>{{ name }}</span>
          <template #overlay>
            <a-menu @click="onContextMenuClick">
              <a-menu-item key="1">选中</a-menu-item>
              <a-menu-item key="2">取消</a-menu-item>
            </a-menu>
          </template>
        </a-dropdown>
      </template>
    </a-tree>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted, reactive, watch, Ref } from 'vue'
import { findTree } from "./api";
const props = defineProps({
  key: {
    type: String,
    default() {
      return 'id'
    }
  },
  checkedKeys: {
    type: Object
  },
  disabled: {
    type: Boolean,
    default() {
      return false;
    }
  }
})
watch( () => props.checkedKeys, (value) => {
  if(value) {
    checkedKeys.value.checked = value
  }
})
const emit = defineEmits(['changeCheck'])
const treeData = ref<any>([]);
const fieldNames = reactive({
  children: 'children', title: 'name', key: props.key
})
const checkedKeys: Ref = ref({
  checked: [],
  halfChecked: []
})
const expandedKeys = ref<any>([0])
watch(() => props.key, (newValue: any) => {
  if (newValue == 'id') {
    expandedKeys.value = [0];
  } else {
    expandedKeys.value = ['-1:0']
  }
})
const bodyData = reactive({
  username: 'mtadn',
  btype: '',
  parent_ids: [-1]
})
onMounted(() => {
  findTree(bodyData).then((res: any) => {
    if(props.disabled) {
      res.data.result.forEach((elment: any) => {
        elment['disableCheckbox'] = true;
      })
    }
    treeData.value = setTree(res.data.result);
  })
})

// 构建组织树
const setTree = (arry: Array<any>) => {
  const parents = arry.find((item: any) => item.id == 0); // 父数组
  const child = arry.filter((item: any) => item.id != 0);
  function arrayToTree(arr: any, parentId: string) {
    const result: any = [];
    for (const item of arr) {
      if (item.parent_id === parentId) {
        const children = arrayToTree(arr, item.id);

        if (children.length) {
          item.children = children;
        }

        result.push(item);
      }
    }
    return result;
  }
  const root = arry.filter((item: any) => item.id == 0);
  root[0].children = arrayToTree(child, parents.id);
  return root;
}
// 拆借树
const openTree = (gg: any) => {
  function treeToFlat(tree: any) {
    const result = [];
    const stack = [...tree];

    while (stack.length > 0) {
      const node = stack.pop();
      result.push(node);

      if (node.children && node.children.length > 0) {
        stack.push(...node.children.reverse());
      }
    }

    return result;
  }
  return treeToFlat(gg)
}
// 选择check
const check = () => {
  emit('changeCheck', checkedKeys.value.checked)
}
// 右击后数据
let rightData = ref<any>([])
// 右击
const rightClick = (e: any) => {
  rightData.value = openTree([e.node])
}
// 右击菜单
const onContextMenuClick = (item: any) => {
  // 1是选中
  if (item['key'] == 1) {
    const chooseKey = rightData.value.map((item: any) => item.id)
    const gg = [...chooseKey, ...checkedKeys.value.checked];
    checkedKeys.value.checked = gg.filter((value, index, self) => {
      return self.indexOf(value) === index;
    });
  } else {
    const chooseKey = rightData.value.map((item: any) => item.id);
    checkedKeys.value.checked = checkedKeys.value.checked.filter((item: any) => !chooseKey.includes(item));
  }
  emit('changeCheck', checkedKeys.value.checked)
};
</script>

<style scoped lang="less">
.tree-box{
  font-size: 12px;
}
:deep(.ant-tree.ant-tree-icon-hide){
  font-size: 12px !important;
}
</style>