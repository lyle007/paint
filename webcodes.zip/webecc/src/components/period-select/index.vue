<template>
  <div class="select">
    <a-range-picker v-model:value="value2" show-time @ok="ok" v-if="active == 'custom'" />
    <a-button class="buttons" size="small" :type="active == 'custom' ? 'primary' : 'default'"
      @click="period('custom')">自定义</a-button>
    <a-button class="buttons" size="small" :type="active == 'day' ? 'primary' : 'default'"
      @click="period('day')">今日</a-button>
    <a-button class="buttons" size="small" :type="active == 'week' ? 'primary' : 'default'"
      @click="period('week')">周</a-button>
    <a-button class="buttons" size="small" :type="active == 'month' ? 'primary' : 'default'"
      @click="period('month')">月</a-button>
  </div>
</template>

<script setup lang="ts">
import { ref } from 'vue'

import  dayjs from 'dayjs';

const emit = defineEmits(['period']);

const active = ref('');

const value2 = ref<any>();

const period = (value: string) => {
  active.value = value;
  if (value == 'day') {
    emit('period', {
      start_time: dayjs().add(-1, 'day').format('YYYY-MM-DD HH:mm:ss'),
      end_time: dayjs().format('YYYY-MM-DD HH:mm:ss'),
    })
  } else if (value == 'week') {
    emit('period', {
      start_time: dayjs().add(-7, 'day').format('YYYY-MM-DD HH:mm:ss'),
      end_time: dayjs().format('YYYY-MM-DD HH:mm:ss'),
    })
  } else if (value == 'month') {
    emit('period', {
      start_time: dayjs().add(-30, 'day').format('YYYY-MM-DD HH:mm:ss'),
      end_time: dayjs().format('YYYY-MM-DD HH:mm:ss'),
    })
  }
}
const ok = () => {
  emit('period', {
    start_time: dayjs(value2.value[0]).format('YYYY-MM-DD HH:mm:ss'),
    end_time: dayjs(value2.value[1]).format('YYYY-MM-DD HH:mm:ss'),
  })
}

</script>

<style scoped lang="less">
.buttons {
  margin-left: 10px;
}

.select {
  display: inline-block
}
</style>