<template>
  <div>
    <a-modal :visible="visible" title="人员选择" @cancel="cancel" @ok="handleOk" cancelText="取消" okText="确定" width="60%">
      <div class="search-box">
        <a-input-search v-model:value="searchData.search" placeholder="用户 名称" style="width: 200px"
            @search="onSearch()" />
      </div>
      <div>
        <a-table rowKey="user_id"
          :row-selection="{ selectedRowKeys: selectedRowKeys, onChange: onSelectChange, getCheckboxProps: getCheckboxProps }"
          :columns="tableData.columns" :pagination="false" :data-source="tableData.dataSource">
          <template #bodyCell="{ column, record }">
            <template v-if="column.key === 'sex'">
              <span>{{ record.sex ? '女' : '男' }}</span>
            </template>
            <template v-if="column.key === 'user_id'">
              <span>{{ record.user_id }}</span>
            </template>
          </template>
        </a-table>
        <a-pagination v-model:current="searchData.page" :total="count" show-less-items @change="changePage()" />
      </div>
    </a-modal>
  </div>
</template>

<script setup lang="ts">
// 豆豆人员选择
import { ref, reactive, onMounted, watch} from 'vue';
import { getAllUserNew } from '@/api/group/index';
const props = defineProps({
  visible: Boolean,
  personList: {
    type: Array,
    default() {
      return []
    }
  },
})
watch(()=> props.personList, (value: any) =>{
  selectedRowKeys.value = value.map((item: any) => item.userID)
})
onMounted(() => {
  getlist()
})
const emit = defineEmits(['handleOk', 'cancel']);
const searchData = reactive({
  page: 1,
  rows: 10,
  search: ''
})
const count = ref(0)
const tableData = reactive<any>({
  dataSource: [],
  columns: [
    {
      title: '用户名',
      dataIndex: 'name',
      key: 'name',
      align: 'center'
    },
    {
      title: '性别',
      dataIndex: 'sex',
      key: 'sex',
      align: 'center'
    },
    {
      title: '姓名',
      dataIndex: 'realname',
      key: 'realname',
      align: 'center'
    },
    {
      title: '用户ID',
      dataIndex: 'user_id',
      key: 'user_id',
      align: 'center'
    },
  ]
})
const selectedRowKeys = ref([])
const selectallROw = ref([])

const getlist = () => {
  getAllUserNew(searchData).then((res: any) => {
    if (res.code == 0) {
      count.value = res.data.total;
      tableData.dataSource = res.data.data;
    }
  })
}
const onSearch = () => {
  getlist()
}
const changePage = () => {
  getlist()
}
let handleOk = () => {
  emit('handleOk', selectallROw.value)
}
let cancel = () => {
  emit('cancel', false)
}
let onSelectChange = (a: any, s: any) => {
  selectedRowKeys.value = a;
  selectallROw.value = s;
}
const getCheckboxProps = (e: any) => {
  return {
    disabled:  props.personList?.map((item: any)=> item.userID).includes(e.user_id)
  }
}
</script>

<style scoped lang="less">
.search-box{
  padding: 10px;
  text-align: right;
}
</style>