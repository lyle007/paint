import axiosInstance from "@/api/http";

/**
 * @auth phy
 * 说明：文件列表
 */

export function getfileList(url: string, data: any) {
  return axiosInstance({
    url: url,
    method: 'post',
    data: data
  })
}

/**
 * @auth phy
 * 说明：删除文件
 */

export function getfileDeletet(url: string, data: any) {
  return axiosInstance({
    url: url,
    method: 'post',
    data: data
  })
}