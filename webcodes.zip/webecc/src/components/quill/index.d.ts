declare module 'quill-image-resize-module';
declare module 'quill-image-drop-module';
