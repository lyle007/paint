<template>
  <div>
    <QuillEditor ref="quillRef" v-model:content="content" :options="options" contentType="html"
      @update:content="setValue" />

    <a-modal v-model:visible="visible" :title="title" @ok="handleOk" width="50%">
      <a-tabs v-model:activeKey="activeKey">
        <a-tab-pane key="1" tab="素材库">
          <a-upload v-model:file-list="fileList" name="upload" :data="data" :action="props.uploadUrl"
            @change="handleChange">
            <a-button>
              <upload-outlined></upload-outlined>
              本地上传
            </a-button>
          </a-upload>
          <div>
            <div>
              <a-checkbox-group v-model:value="chooseValue" class="imglist">
                <div v-for="item in imgList" :key="item['id']" class="imglist-item">
                  <a-checkbox :value="item['id']" class="check"></a-checkbox>
                  <img :src="item['file_url']" alt="" srcset="" v-if="data.category == 1">
                  <video :src="item['file_url']" alt="" srcset="" v-if="data.category == 2"></video>
                  <a-popover trigger="click">
                    <template #content>
                      <p style="margin-bottom: 10px;"><a-button type="primary" @click="review(item)">预览</a-button></p>
                      <p><a-button @click="delctss(item)">删除</a-button></p>
                    </template>
                    <div class="end">
                      <ellipsis-outlined />
                    </div>
                  </a-popover>
                </div>
              </a-checkbox-group>
            </div>
            <a-pagination v-model:current="querys.page" :total="count" show-less-items @change="changePage()" />
          </div>
        </a-tab-pane>
        <a-tab-pane key="2" :tab="data.category == 1 ? '图片地址' : '视频地址'" force-render>
          <a-row>
            <a-col :span="3">{{ data.category == 1 ? '图片地址' : '视频地址' }}：</a-col>
            <a-col :span="20"><a-input v-model:value="link" placeholder="请输入链接" /></a-col>
          </a-row>
        </a-tab-pane>
      </a-tabs>
    </a-modal>
    <a-modal v-model:visible="previewVis" :footer="null">
      <div class="previewVis">
        <img :src="rowData['file_url']" alt="" v-if="data.category == 1">
        <video :src="rowData['file_url']" alt="" controls v-if="data.category == 2"></video>
      </div>
    </a-modal>
  </div>
</template>

<script setup lang="ts">
import { ref, watch, toRaw, reactive, onMounted } from "vue";
import { QuillEditor } from '@vueup/vue-quill'
import '@vueup/vue-quill/dist/vue-quill.snow.css';
import type { UploadChangeParam } from 'ant-design-vue';
import { message } from 'ant-design-vue';
import { EllipsisOutlined, UploadOutlined } from '@ant-design/icons-vue';


import { getfileList, getfileDeletet } from './api'
const quillRef = ref<any>(null);
const props = defineProps({
  modelValue: {
    type: String,
    default() {
      return ''
    }
  }, // 双向绑定值
  listUrl: {
    type: String,
    default() {
      return '/ecs/api/v1.0/admin/material/find_all'
    }
  },
  uploadUrl: {
    type: String,
    default() {
      return `/ecs/api/v1.0/admin/material/upload?access_token=${sessionStorage.getItem('access_token')}`
    }
  },
  delectUrl: {
    type: String,
    default() {
      return `/ecs/api/v1.0/admin/material/delete`
    }
  }
})
const visible = ref(false);
const previewVis = ref(false);
const title = ref('选择图片');
const imageClick = () => {
  title.value = '选择图片'
  data.category = 1;
  querys.category = 1;
  fileLists()
  visible.value = true;
}
const videoClick = () => {
  title.value = '选择视频'
  data.category = 2;
  querys.category = 2;
  fileLists()
  visible.value = true
}
const querys = reactive({
  page: 1,
  rows: 12,
  search: "",
  category: 1
})
const count = ref(0)
const imgList = ref([])
const data = reactive({
  category: 1
})
const link = ref('')
const activeKey = ref('1')
// 选中的文件；
const chooseValue = ref<any>([]);

const fileList = ref([])
// 选择视频 或 者照片
const handleOk = () => {
  console.log(chooseValue.value)
  if (activeKey.value === '1') {
    if (data.category === 1) {
      const arrs = imgList.value.filter((item: any) => chooseValue.value.includes(item.id))
      arrs.forEach((element: any) => {
        content.value += `<image src="${element.file_url}""></image>`
      })
    } else {
      const arrs = imgList.value.filter((item: any) => chooseValue.value.includes(item.id))
      arrs.forEach((element: any) => {
        content.value += `<iframe src="${element.file_url}" class="ql-video" frameborder="0" allowfullscreen="true"></iframe>`
      })
    }
  } else {
    if (data.category === 1) {
      content.value += `<image src="${link.value}""></image>`
    } else {
      content.value += `<iframe src="${link.value}" class="ql-video" frameborder="0" allowfullscreen="true"></iframe>`
    }
  }
  link.value = ''
  visible.value = false
}
const handleChange = (info: UploadChangeParam) => {
  if (info.file.status === 'done') {
    message.success(`${info.file.name}上传成功`);
    fileList.value = [];
    fileLists()
  } else {
    // message.warn('上传失败')
  }
}
// 文件列表
const fileLists = () => {
  getfileList(props.listUrl, querys).then(((res: any) => {
    console.log(res)
    count.value = res.data.count;
    imgList.value = res.data.result;
  }))
}
// 翻页
const changePage = () => {
  fileLists();
}
// 删除
const delctss = (item: any) => {
  getfileDeletet(props.delectUrl, { ids: [item.id] }).then(() => {
    message.warn('删除成功')
    fileLists()
  })
}
const rowData = ref({
  file_url: ''
})
const review = (item: any) => {
  rowData.value = item
  previewVis.value = true
}
const options = reactive({
  modules: {
    toolbar: {
      container: [
        ['bold', 'italic', 'underline'], // 加粗 斜体 下划线 删除线
        [{ color: [] }, { background: [] }], // 字体颜色、字体背景颜色
        ['blockquote',], // 引用  代码块
        [{ header: 1 }, { header: 2 }], // 1、2 级标题
        [{ list: 'ordered' }, { list: 'bullet' }], // 有序、无序列表
        [{ script: 'sub' }, { script: 'super' }], // 上标/下标
        [{ indent: '-1' }, { indent: '+1' }], // 缩进
        [{ size: ['small', 'large', 'huge'] }], // 字体大小
        [{ header: [1, 2, 3, 4, 5, 6] }], // 标题
        [{ align: [] }], // 对齐方式
        ['clean'], // 清除文本格式
        ["link", 'image', 'video']// 链接、图片、视频
      ],
      handlers: {
        'image': imageClick,
        'video': videoClick,
      }
    },
  },
  placeholder: '请输入文本',
  theme: 'snow',
  language: 'zh-cn',
})
const content = ref(props.modelValue);
const emit = defineEmits<{
  (e: 'update:modelValue', val: any): void
}>()

const setValue = () => { //用于设置双向绑定值
  const text = toRaw(quillRef.value).getHTML()
  emit('update:modelValue', text)
}

watch(() => props.modelValue, (val: any) => {
  if (val) {
    content.value = val //用于监听绑定值进行数据回填
  } else {
    toRaw(quillRef.value).setContents('') //可用于弹窗使用富文本框关闭弹窗清除值
  }
})
onMounted(() => {
  initButtonTitle();
  console.log(quillRef.value)
})
// 标签汉化
const initButtonTitle = () => {
  const titleConfig = [
    { Choice: ".ql-bold", title: "加粗" },
    { Choice: ".ql-italic", title: "斜体" },
    { Choice: ".ql-underline", title: "下划线" },
    { Choice: ".ql-header", title: "段落格式" },
    { Choice: ".ql-strike", title: "删除线" },
    { Choice: ".ql-blockquote", title: "块引用" },
    { Choice: ".ql-code", title: "插入代码" },
    { Choice: ".ql-code-block", title: "插入代码段" },
    { Choice: ".ql-font", title: "字体" },
    { Choice: ".ql-size", title: "字体大小" },
    { Choice: '.ql-list[value="ordered"]', title: "编号列表" },
    { Choice: '.ql-list[value="bullet"]', title: "项目列表" },
    { Choice: ".ql-direction", title: "文本方向" },
    { Choice: '.ql-header[value="1"]', title: "h1" },
    { Choice: '.ql-header[value="2"]', title: "h2" },
    { Choice: ".ql-align", title: "对齐方式" },
    { Choice: ".ql-color", title: "字体颜色" },
    { Choice: ".ql-background", title: "背景颜色" },
    { Choice: ".ql-image", title: "图像" },
    { Choice: ".ql-video", title: "视频" },
    { Choice: ".ql-link", title: "添加链接" },
    { Choice: ".ql-formula", title: "插入公式" },
    { Choice: ".ql-clean", title: "清除字体格式" },
    { Choice: '.ql-script[value="sub"]', title: "下标" },
    { Choice: '.ql-script[value="super"]', title: "上标" },
    { Choice: '.ql-indent[value="-1"]', title: "向左缩进" },
    { Choice: '.ql-indent[value="+1"]', title: "向右缩进" },
    { Choice: ".ql-header .ql-picker-label", title: "标题大小" },
    {
      Choice: '.ql-header .ql-picker-item[data-value="1"]',
      title: "标题一",
    },
    {
      Choice: '.ql-header .ql-picker-item[data-value="2"]',
      title: "标题二",
    },
    {
      Choice: '.ql-header .ql-picker-item[data-value="3"]',
      title: "标题三",
    },
    {
      Choice: '.ql-header .ql-picker-item[data-value="4"]',
      title: "标题四",
    },
    {
      Choice: '.ql-header .ql-picker-item[data-value="5"]',
      title: "标题五",
    },
    {
      Choice: '.ql-header .ql-picker-item[data-value="6"]',
      title: "标题六",
    },
    { Choice: ".ql-header .ql-picker-item:last-child", title: "标准" },
    {
      Choice: '.ql-size .ql-picker-item[data-value="small"]',
      title: "小号",
    },
    {
      Choice: '.ql-size .ql-picker-item[data-value="large"]',
      title: "大号",
    },
    {
      Choice: '.ql-size .ql-picker-item[data-value="huge"]',
      title: "超大号",
    },
    { Choice: ".ql-size .ql-picker-item:nth-child(2)", title: "标准" },
    { Choice: ".ql-align .ql-picker-item:first-child", title: "居左对齐" },
    {
      Choice: '.ql-align .ql-picker-item[data-value="center"]',
      title: "居中对齐",
    },
    {
      Choice: '.ql-align .ql-picker-item[data-value="right"]',
      title: "居右对齐",
    },
    {
      Choice: '.ql-align .ql-picker-item[data-value="justify"]',
      title: "两端对齐",
    },
  ];
  setTimeout(() => {
    for (let item of titleConfig) {
      let tip = document.querySelector(item.Choice)
      if (!tip) continue
      tip.setAttribute('title', item.title)
    }
  }, 1000);
}
</script>

<style scoped lang="less">
// 调整样式
:deep(.ql-editor) {
  min-height: 180px;
}

:deep(.ql-formats) {
  height: 21px;
  line-height: 21px;
}

.imglist {
  display: flex;
  flex-wrap: wrap;
  justify-content: space-between;

  .imglist-item {
    width: 24%;
    height: 80px;
    border: 1px solid #ccc;
    margin: 10px 0;
    position: relative;

    img {
      width: 100px;
      height: 100%;
    }

    video {
      width: 100px;
      height: 100%;
    }

    .check {
      position: absolute;
      top: 0;
      left: 0;
    }

    .end {
      position: absolute;
      top: 0;
      right: 0;
      z-index: 2;
      font-size: 16px;
    }
  }
}
.previewVis{
  padding-top: 20px;
  img{
    width: 100%;
  }
  video{
    width: 100%;
  }
}
</style>