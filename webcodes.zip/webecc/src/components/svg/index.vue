<template>
  <div :style="{width: `${width}px`, height: `${height}px`}" class="svgs">
    <svg aria-hidden="true" :width="width" :height="height">
      <use :xlink:href="symbolId" :fill="fill" />
    </svg>
  </div>
</template>

<script setup lang="ts">
import { computed } from 'vue';
// **
//  * 输入属性             类型                默认值              是否必选                描述
//  *  name              string             undefined              是                  svg图标名字
//  *  width             number                24                  否                  svg图标宽度
//  *  height            number                24                  否                  svg图标高度
//  *  fill              string              #ffffff               否                  svg图标填充颜色
//  */
const props = withDefaults(
  defineProps<{
    name: string;
    width?: string;
    height?: string;
    fill?: string;
  }>(),
  {
    width: '30',
    height: '30',
    fill: '#ffffff',
  }
);

// 获取svg图标名称，需要和vite.config.ts中的配置保持一致
const symbolId = computed(() => `#${props.name}`);
</script>

<style lang="less" scoped>
.svgs{
  display: inline-block;
  line-height: 1;
}
</style>