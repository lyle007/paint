/**
 *  开发  develop
 *  生产  produce
 */
let environment = 'develop'  // 环境 
export let ACCOUNT = {
  extId: '1956353e6864cb442438c7dfae29257da50111af',
  clientId: 'OX3fO1nlonbE15Xn4ZWkD0El',
  clientSecret: '7XnxiZcWbWxt7hvFlaY73xtJqoFg1Yho',
};
export let DOUDOU = {
  appID: '4611686027040362497',
  appSecret: 'bB6rUZTZUrl6HPcttaJ1Et5TcB5yxE4b1uaxi7k-erq_FEKDONJPoyZym-cLB1dU_1aiBbQk8dboNQZwuFQwzQ'
}
export let DOUDOUM = {
  appID: '4611686027040362498',
  appSecret: 'bB6rUZTZUrl6HPcttaJ1Et7Ca8q6_q_9rinS5J_LlZ6JtRtlmr5OX47ZE4sEdNg4PRtRm_r8DzyWZbosjOVnrw'
}

if (environment == 'develop') {
  // 小鱼； mt
  ACCOUNT = {
    extId: '1956353e6864cb442438c7dfae29257da50111af',
    clientId: 'OX3fO1nlonbE15Xn4ZWkD0El',
    clientSecret: '7XnxiZcWbWxt7hvFlaY73xtJqoFg1Yho',
  };
  // 应用助手； 应用
  DOUDOU = {
    appID: '4611686027040362497',
    appSecret: 'bB6rUZTZUrl6HPcttaJ1Et5TcB5yxE4b1uaxi7k-erq_FEKDONJPoyZym-cLB1dU_1aiBbQk8dboNQZwuFQwzQ'
  }
  // 智能助手： 订阅
  DOUDOUM = {
    appID: '4611686027040362498',
    appSecret: 'bB6rUZTZUrl6HPcttaJ1Et7Ca8q6_q_9rinS5J_LlZ6JtRtlmr5OX47ZE4sEdNg4PRtRm_r8DzyWZbosjOVnrw'
  }
} else {
  // 中航信小鱼web，云上ECC
  ACCOUNT = {
    extId: 'd0936940271fbda2a23708ac60ac80a8c71ab7eb',
    clientId: '4TJOhyzXovWp9aJFb03Kifea',
    clientSecret: 'qhr7KaneoxQZRAqvKrGljvh27Yn6EPca',
  };

  DOUDOU = {
    appID: '21256825174',
    appSecret: 'EKpeYZJp-mQGj3sHVn-ujvRZGBnWHjD5eNx77huBX_JVlDvuGp9Kxzkm_6VmroYJ'
  }

  DOUDOUM = {
    appID: '21256825175',
    appSecret: 'Y_kSXnhyb9ALI-BrjCwVuXadiez0GgK5DH4mp03-a4QI9jSOVwz_6MxXDyXNUMUQ'
  }
}

