/*
 * @ auto phy
 * 说明： 字典文件
 */

// 组件类型
export const comType = [
  {
    value: '1',
    label: '内部模块'
  },
  {
    value: '2',
    label: '外部URL'
  },
] 
// 组件形状
export const comState = [
  {
    value: '1',
    label: '侧边栏'
  },
  {
    value: '2',
    label: '全尺寸'
  },
  {
    value: '3',
    label: '1/2尺寸'
  },
]