<template>
  <div>
    <ul class="mt-head" :style="{ color: headerTextColor }">
      <li class="header-left">
        <vue3-seamless-scroll :list="tableDate.dataSource" :hover="true" :count="1" :isWatch="true" :limitScrollNum="1"
          :step="1" :singleHeight="40" :singleWaitTime="2000" class="scroll">
          <div class="item " v-for="(item, index) in tableDate.dataSource" :key="index">
            <span class="item-title mt-text-one" @click="toMessage(item)">
              <message-outlined :style="{ color: '#FF0000' }" />{{ item['title'] }}
            </span>
          </div>
        </vue3-seamless-scroll>
      </li>
      <li class="header-center">
        <div class="header-center-box">
          <span class="mt-title mt-text-one">Paint management </span>
        </div>

      </li>
      <li class="header-right">
        <div class="header-right-text">
          <div class="date mt-text-one">{{ newtime }}</div>
        </div>
        <div class="header-right-box">
          <div class="mt-head-item">
            <a-tooltip title="退出登录">
              <i nz-icon class="icon anticon" @click="outlogin()">
                <svg t="1591694873280" viewBox="0 0 1024 1024" version="1.1" xmlns="http://www.w3.org/2000/svg"
                  p-id="3799" width="24" height="24">
                  <path fill="currentColor"
                    d="M512 1011.712C237.568 1011.712 16.384 790.528 16.384 516.096 16.384 241.664 237.568 20.48 512 20.48c122.88 0 241.664 45.056 335.872 131.072 8.192 0 12.288 12.288 12.288 20.48 0 12.288-4.096 20.48-12.288 28.672-16.384 16.384-40.96 16.384-57.344 4.096-77.824-69.632-176.128-106.496-278.528-106.496C286.72 98.304 98.304 282.624 98.304 512s184.32 413.696 413.696 413.696c102.4 0 200.704-36.864 278.528-106.496 8.192-8.192 20.48-12.288 28.672-12.288 12.288 0 20.48 4.096 28.672 12.288 8.192 8.192 12.288 20.48 12.288 28.672 0 12.288-4.096 20.48-12.288 28.672-90.112 86.016-208.896 135.168-335.872 135.168"
                    p-id="3800"></path>
                  <path fill="currentColor"
                    d="M876.544 552.96H348.16c-24.576 0-40.96-20.48-40.96-40.96 0-24.576 20.48-40.96 40.96-40.96h528.384l-90.112-94.208c-16.384-16.384-16.384-40.96 0-57.344 16.384-16.384 40.96-16.384 57.344 0l155.648 159.744c8.192 8.192 12.288 20.48 12.288 32.768v4.096c0 12.288-4.096 24.576-12.288 32.768l-155.648 159.744c-16.384 16.384-40.96 16.384-57.344 0-16.384-16.384-16.384-40.96 0-57.344l90.112-98.304z m0 0"
                    p-id="3801" fi></path>
                </svg>
              </i>
            </a-tooltip>
          </div>
          <div class="mt-head-item">
            <a-tooltip title="个人信息">
              <a-dropdown :trigger="['click']">
                <span>{{ user ? user.username : "" }}</span>
                <template #overlay>
                  <a-menu>
                    <a-menu-item>
                      <a href="javascript:;">{{ user ? user.org_name : '' }}</a>
                    </a-menu-item>
                    <a-menu-item>
                      <a href="javascript:;">{{ user ? user.role_name : '' }}</a>
                    </a-menu-item>
                    <a-menu-item>
                      <a href="javascript:;">{{ user ? user.name : '' }}</a>
                    </a-menu-item>
                  </a-menu>
                </template>
              </a-dropdown>
            </a-tooltip>
          </div>
        </div>
      </li>
      <!-- <img class="header-images" src="@/assets/bgimages/headbg.png" alt=""> -->
    </ul>
  </div>
</template>

<script setup lang="ts">
import { MessageOutlined } from '@ant-design/icons-vue';
import { FullscreenOutlined, FullscreenExitOutlined } from '@ant-design/icons-vue';
import { useCounterStore } from "../../store/index"
import { ref, reactive, onMounted, watch} from 'vue';
import { Vue3SeamlessScroll } from "vue3-seamless-scroll";
import { dateFormat } from "@/utils/filter"
import { storeToRefs } from 'pinia'
import { useRouter } from "vue-router";
import dayjs from 'dayjs'

import { newUserhistory } from '@/api/messagemanage/index';
const tableDate = reactive({
  dataSource: []
})
const getlist = () => {
  let user: any = sessionStorage.getItem('user');
  user = JSON.parse(user)
  const obj = {
    user_id: user.username,
    role: user.role,
    status: 4,
    start_time: dayjs().add(-1, 'day').format('YYYY-MM-DD HH:mm:ss'),
    end_time: dayjs().format('YYYY-MM-DD HH:mm:ss'),
  }
  newUserhistory(obj).then((res: any) => {
    tableDate.dataSource = res.data.result;
  })
}
const router = useRouter()

let user = ref<any>({})

onMounted(() => {
  let userInfo: any = sessionStorage.getItem('user') ? sessionStorage.getItem('user') : {}
  user.value = JSON.parse(userInfo);
  getlist()
})

defineProps({
  defaultDae: Boolean
})
let headerTextColor = ref('#000'); // 字体颜色
const useStore = useCounterStore()
const { fullScreen } = useStore

const tofullScreen = () => {
  fullScreen()
}

const { socket, readMessage } = storeToRefs(useStore)

watch(readMessage, () => {
  getlist()
})
// 退出登录
const outlogin = () => {
  let path: any;
  path = localStorage.getItem('fLogin') ? localStorage.getItem('fLogin') : '/userlogin'
  socket.value.disconnect();
  socket.value =  null;
  
  // 清除缓存
  sessionStorage.clear()
  // 跳转至登录页面
  router.push({
    path: path,

  })
}
// 跳转消息
const toMessage = (item: any) => {
  router.push({
    path: "/messagemanage/details",
    query: {
      id: item.id
    }
  })
}

// 计时器
const newtime = ref('')
setInterval(() => {
  newtime.value = dateFormat(new Date(),false)
}, 1000);
headerTextColor = JSON.parse(localStorage.getItem('platformInfo')!) ? JSON.parse(localStorage.getItem('platformInfo')!).head_text_color : '#000'
</script>

<style lang="less" scoped>
.header-button {
  margin-left: 32px;
  padding-top: 23px;
}

.header-left {
  position: absolute;
  // background-color: red;
  left: 10px;
  height: 40px;
  width: 28%;
  overflow: hidden;
  margin-top: 5px;
  margin-left: 20px;
  display: flex;
  justify-content: flex-start;
  color: #fff;
  font-weight: 400;

  .scroll {
    height: 40px;
    width: 100%;
  }

  span {
    margin-right: 10px;
  }

  .item {
    height: 40px;
    width: 100%;
    line-height: 50px;
    padding: 0 10px;

    .item-title {
      display: inline-block;
      width: 100%;
      color: #fff;
    }

  }
}

.header-center {
  position: absolute;
  left: 50%;
  margin-left: -125px;
  // width: 30%;

  .header-center-box {
    display: flex;
    justify-content: space-around;
  }
}

.header-right {
  position: absolute;
  right: 0px;
  width: 35%;
  display: flex;
  justify-content: flex-end;
  color: #fff;
  font-weight: 400;
  overflow: hidden;

  .header-right-text {
    display: flex;
    justify-content: space-around;
    margin-right: 20px;
    height: 20px;
    line-height: 20px;
    position: absolute;
    top: 22px;
    right: 120px;


    .personnel {
      margin-left: 20px;
    }
  }

  .header-right-box {
    display: flex;
    justify-content: space-around;
  }
}

.mt-head {
  position: relative;
  display: flex;
  justify-content: space-between;
  padding: 0;
  background-size: 100% 100%;
  background-repeat: no-repeat;
  background-position: 50% 0%;
  z-index: 99;

  .header-images {
    width: 100%;
    height: 66px;
    position: absolute;
    z-index: -1;
  }
}

.icons {
  font-size: 24px;
  color: #fff;
}

li {
  list-style-type: none;
  display: flex;
  justify-content: space-around;

  .mt-head-item {
    display: flex;
    align-items: center;
    font-size: 16px;
    margin-right: 10px;

    .anticon {
      color: #fff;
    }
  }



  .logo {
    width: 70px;

    img {
      height: 30px;
    }
  }
}

.mt-title {
  font-size: 18px;
  font-weight: 400;
  color: white;

}
</style>
