<template>
  <a-layout>
    <a-layout-header :style="{
      position: 'fixed',
      zIndex: 1,
      width: '100%',
      background: '#1890ff',
      margin: '0 0 5px 0'
    }">
      <heads :defaultDae="true"></heads>
    </a-layout-header>
    <a-layout class="layout-main">
      <a-layout-sider :class="['siders', (collapsed ? 'show-sider' : 'show-sider-max')]"
        class="siders 'show-sider'" v-model:collapsed="collapsed" :trigger="null" collapsible>
        <menus @click-menu="clickMune"></menus>
        <div class="show-menu" @click="menuShowBtn()">
          <RightOutlined v-if="collapsed"></RightOutlined>
          <LeftOutlined v-else></LeftOutlined>
        </div>
      </a-layout-sider>
      <a-layout-content class="contents">
        <router-view>
        </router-view>
      </a-layout-content>
    </a-layout>
  </a-layout>
</template>

<script setup lang="ts">
import { RightOutlined, LeftOutlined } from '@ant-design/icons-vue';
import heads from '@/layout/head/index.vue';
import menus from '@/layout/menu/index.vue';
import { ref} from 'vue';
import { RouteLocationNormalized, useRoute, useRouter, } from "vue-router";
let breadcrumb = ref<any[]>([]) // 面包屑数据
const route = useRoute();
const router = useRouter();
router.beforeResolve(async (to: any) => {
  if (to.meta.level && to.meta.level > 2) {
    breadcrumb.value.push(to);
  } else {
    breadcrumb.value = to.matched.slice(1, to.matched.length);
  }
})

breadcrumb.value = route.matched.slice(1, route.matched.length);
const clickMune = () => {
  breadcrumb.value = route.matched.slice(1, route.matched.length);
}
// 菜单展开收起
let collapsed = ref(false)
const menuShowBtn = () => {
  collapsed.value = !collapsed.value;
}
// 面包屑





</script>

<style lang="less" scoped>
.layout-main {
  height: calc(100vh - 65px);
  margin-top: 65px;
}

.siders {
  height: 100%;
  background-color: #fff;
  position: relative;
}

.show-sider {
  width: 40px !important;
  max-width: 40px !important;
  min-width: 40px !important;
  transition: all 0.5s;
}

.show-sider-max {
  width: 200px !important;
  max-width: 200px !important;
  min-width: 200px !important;
  transition: all 0.5s;
}

.no-sider {
  width: 0px !important;
  max-width: 0px !important;
  min-width: 0px !important;
  transition: all 0.5s;
}

.contents {
  padding: 0px 10px 0px 10px;
}

.show-menu {
  position: absolute;
  bottom: 10px;
  font-size: 14px;
  width: 100%;
  text-align: center;
}
</style>
