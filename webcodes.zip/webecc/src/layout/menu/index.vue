<template>
  <div>
    <a-menu v-model:selectedKeys="selectedKeys" mode="inline" :open-keys="openKeys" @click="onClickMenu"
      @openChange="onOpenChange">
      <template v-for="item in outChildren">
        <a-menu-item v-if="!item.children && item.meta!['showMenu']" :key="item.path" :title="item.meta!.title">
          <template #icon>
            <svg-icon name="mt_home" v-if="item['path'] == 'home'" width="16" height="16"></svg-icon>
            <svg-icon name="mt_setting" v-if="item['path'] == 'setting'" width="16" height="16"></svg-icon>
            <svg-icon name="mt-duty" v-if="item['path'] == 'dutymanage'" width="16" height="16"></svg-icon>
           
          </template>
          {{ item.meta!.title }}</a-menu-item>
        <a-sub-menu v-if="item.children" :key="item.path" :title="item.meta!.title">
          <template #icon>
            <svg-icon name="mt_message" v-if="item['path'] == 'messagemanage'" width="16" height="16"></svg-icon>
            <svg-icon name="mt_message" v-if="item['path'] == 'eventmanage'" width="16" height="16"></svg-icon>
            <svg-icon name="mt_fault" v-if="item['path'] == 'fault'" width="16" height="16"></svg-icon>
            <svg-icon name="mt_mis" v-if="item['path'] == 'component'" width="16" height="16"></svg-icon>
            <svg-icon name="mt_group" v-if="item['path'] == 'group'" width="16" height="16"></svg-icon>
          </template>
          <template #title>{{ item.meta!.title }}</template>
          <template v-for="itemChild in item.children" :key="itemChild.path">
            <a-menu-item v-if="itemChild.meta!.showMenu" :key="itemChild.path" :title="itemChild.meta!.title">
              {{ itemChild.name }}
            </a-menu-item>
          </template>
        </a-sub-menu>
      </template>
    </a-menu>
  </div>
</template>

<script setup lang="ts">
import { ref } from "vue";
import { useRouter } from "vue-router";
import outChildren from '@/router/modules-index'; // layout路由信息

const router = useRouter()
let openKeys = ref()
let selectedKeys = ref();
// 自定义事件
const emit = defineEmits(['open-menu', 'click-menu'])
const onOpenChange = (e: any) => {
  const g = [e[e.length - 1]]
  openKeys.value = g;
}
const onClickMenu = (e: any) => {
  let url = ''
  e.keyPath.forEach((item: any) => {
    url += `/${item}`
  })
  router.push({
    path: url
  }).then(() => {
    emit('click-menu', e)
  })

}
</script>

<style lang="less" scoped></style>
