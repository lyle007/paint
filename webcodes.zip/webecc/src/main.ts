import { createApp } from 'vue'
import './style.css'
import VueFullscreen from 'vue-fullscreen'
import App from './App.vue'
import router from './router';
import pinia from './store';

import svgIcon from './components/svg/index';
import empty from './components/empty/index'
import VueGridLayout from 'vue-grid-layout' // 引入layout

import Antd from 'ant-design-vue';
import 'ant-design-vue/dist/antd.less';
import 'ant-design-vue/dist/antd.variable.less';
import '@/theme/default.less'
import '@/theme/index.less'

const app = createApp(App);

app.use(router);
app.use(VueGridLayout);
app.use(VueFullscreen)
app.use(empty)
app.use(pinia);
app.use(Antd)
app.use(svgIcon)
app.mount('#app');
