// 路由守卫 + 权限控制
import type { Router } from 'vue-router';

export function createRouterGuards(router: Router) {
  router.beforeEach(async (to, from, next) => {
    // 导航判断
    console.log(from)
    const access_token = sessionStorage.getItem('access_token') || to.query.access_token as string;
    if (access_token && to.path.indexOf('login') == -1) {
      sessionStorage.setItem('access_token', access_token)
      next()
    } else {
      if (to.path.indexOf('login') != -1) {
        next()
      } else {
        let path: any;
        path = localStorage.getItem('fLogin') ? localStorage.getItem('fLogin') : '/userlogin'
        next(path)
      }
    }
  })
}