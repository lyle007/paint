import { createRouter, createWebHashHistory } from 'vue-router';
import type { RouteRecordRaw } from 'vue-router';
import outChildren from "./modules-index"
import { createRouterGuards} from './guard/index'
export const routes: Array<RouteRecordRaw> = [
  {
    path: '/',
    name: 'Layout',
    redirect: 'group',
    component: () => import('@/layout/index.vue'),
    meta: {
      title: 'layout',
    },
    children: outChildren
  },
  {
    path: '/login',
    name: 'login',
    component: () => import('@/view/login/index.vue'),
    meta: {
      title: 'login',
    },
  },
];

export const router = createRouter({
  history: createWebHashHistory(),
  routes,
});
// 添加路由守卫
createRouterGuards(router)
export default router;