
import group from '@/router/modules/group'


export default [ ...group];