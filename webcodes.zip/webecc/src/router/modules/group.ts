import type { RouteRecordRaw } from 'vue-router';

const routes: Array<RouteRecordRaw> = [
  {
    path: 'group',
    redirect: '/group/groupList',
    name: 'Paint management',
    meta: {
      title: 'Paint',
      showMenu: true, // 是否为菜单
      licenseControl: false, // 是否受后台权限控制，
      code: 'sap',   // 后台权限编码
      level: 1
    },
    children: [
      {
        path: 'groupList',
        name: `PaintColor`,
        component: () => import('@/view/group/list/index.vue'),
        meta: { title: 'colorff', showMenu: true, licenseControl: true, code: 'sap-001-001-008', level: 2 },
        children: [
          
        ]
      },
      {
        path: 'user',
        name: `user`,
        component: () => import('@/view/group/user/index.vue'),
        meta: { title: 'user', showMenu: true, licenseControl: false, code: 'sap-001-001-008-001', level: 3 },
      }
    ]
  },
];

export default routes;