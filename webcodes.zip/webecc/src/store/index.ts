import { createPinia, defineStore } from 'pinia';
import piniaPluginPersistedstate from 'pinia-plugin-persistedstate';
const VITE_API_WEBSOCK = import.meta.env.VITE_API_WEBSOCK;


import { io } from 'socket.io-client';
export const useCounterStore = defineStore('counter', {
    state: () => ({
        isFullscreen: false,//全屏
        catMessage: "",
        messages: {},//豆豆消息
        messageWarning: {},//富文本消息

        faultMessage: null,//故障消息
        faultList: {},//故障列表
        faultCount: 0,//未解决故障数量
        eventList: null,//事件列表
        eventCount: 0,//在线事件数量
        ondutyCount: 0,//当前值班人数
        socket: <any>{},

        readMessage: 0,

    }),

    actions: {
        // socket
        connect() {
            const userName = sessionStorage.getItem('user') ? JSON.parse(sessionStorage.getItem('user') || '').username : 'mtadn';
            const offset = localStorage.getItem('offset');
            const socket = io((process.env.NODE_ENV == "development" ? VITE_API_WEBSOCK : location.origin) + '?user_id=' + userName + "&event_id=1000" + "&offset=" + offset, {
                transports: ['websocket'], // 指定传输方式，如WebSocket
                autoConnect: true, // 是否自动连接
                reconnection: true, // 是否自动重新连接
                reconnectionAttempts: Infinity, // 重新连接尝试次数
                reconnectionDelay: 1000, // 重新连接延迟时间（毫秒）
                query: { token: 'your-token' }, // 自定义查询参数
                // 其他可选参数...
            });
            this.socket = socket
            // 判断是否连接成功
            socket.on("connect", () => {
                console.log(socket.id); // "G5p5..."
            });
            // 这里是对应的接收处理------事件
            socket.on('E001001', (data: any) => {
                // 处理接收到的数据
                this.eventList = data
            });
            // 这里是对应的接收处理------故障
            socket.on('E002001', (data: any) => {
                // 处理接收到的数据
                this.faultList = data
            });

            // 这里是对应的接收处理------故障消息
            socket.on('E002002', (data: any) => {
                // 处理接收到的数据
                this.faultMessage = data
            });

            // 聊天消息
            socket.on('E005001', (data: any) => {
                // 处理接收到的数据
                this.messages = JSON.parse(data.message)
            });
            // 富文本消息
            socket.on('E007001', (data: any) => {
                // 处理接收到的数据
                this.messageWarning = data.message || data;
                if (data) {
                    localStorage.setItem('offset', data.offset)
                }
            });

            // 在线事件数
            socket.on('E100001', (data: any) => {
                // 处理接收到的数据
                this.eventCount = data.online_count
            });

            // 未解决故障数
            socket.on('E100002', (data: any) => {
                // 处理接收到的数据
                this.faultCount = data.open_count
            });

            // 当前值班人数
            socket.on('E100003', (data: any) => {
                // 处理接收到的数据
                this.ondutyCount = data.onduty_count
            });

            socket.on("incident", (reason: any) => {
                if (reason === "io server disconnect") {
                    // the disconnection was initiated by the server, you need to reconnect manually
                    socket.connect();
                }
                if (reason == "transport close") {
                    console.log("新建链接");
                }
            });
            //重试失败后会调用reconnect_failed事件
            socket.on('reconnect_failed', function () {
                console.log('reconnect_failed',);
            })
        },


        // 全屏
        fullScreen() {
            this.isFullscreen = !this.isFullscreen
        }

    },
})

const pinia = createPinia();
pinia.use(piniaPluginPersistedstate);
export default pinia;