import * as CryptoJS from 'crypto-js';

export function enCode(str: string, value: string) {
  const key = CryptoJS.enc.Utf8.parse(str),
    iv = CryptoJS.enc.Utf8.parse(str);
  const envalue = CryptoJS.AES.encrypt(value, key, {
    iv: iv,
    mode: CryptoJS.mode.CBC,
    padding: CryptoJS.pad.Pkcs7,
  }).toString();
  return envalue;
}

export function deCode(str: string, value: string) {
  const key = CryptoJS.enc.Utf8.parse(str),
    iv = CryptoJS.enc.Utf8.parse(str);
  const bytes = CryptoJS.AES.decrypt(value, key, {
    iv: iv,
    mode: CryptoJS.mode.CBC,
    padding: CryptoJS.pad.Pkcs7,
  });
  const devalue = bytes.toString(CryptoJS.enc.Utf8);
  return devalue;
}

export function Encrypt(key: string, word: string) {
  const key2 = CryptoJS.enc.Hex.parse(key);
  const srcs = CryptoJS.enc.Utf8.parse(word);
  const encrypted = CryptoJS.AES.encrypt(srcs, key2, {
    mode: CryptoJS.mode.ECB,
    padding: CryptoJS.pad.Pkcs7,
  });
  return encrypted.toString();
}

export function Decrypt(key: string, word: string) {
  const key2 = CryptoJS.enc.Hex.parse(key);
  const decrypt = CryptoJS.AES.decrypt(word, key2, {
    mode: CryptoJS.mode.ECB,
    padding: CryptoJS.pad.Pkcs7,
  });
  return CryptoJS.enc.Utf8.stringify(decrypt).toString();
}