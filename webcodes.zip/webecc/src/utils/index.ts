export function analysisMess () {
  const PATTERN_NEW_INCIDENT: any = /[0-9]+/g;
  PATTERN_NEW_INCIDENT
}