export  interface creatGroup {
  groupName: string,
  groupIcon: string,
  groupType: any,
  groupLevel: Number,
  groupBrief: string,
  groupBulletin: string,
  initGroupMembers: Array<any>
}