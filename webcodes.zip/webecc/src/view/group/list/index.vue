<template>
  <div>
    <a-layout>
      <a-layout-header :style="{ background: '#fff', width: '100%', borderBottom: '1px solid #e7e7e7' }">
        <div class="search-head">
          <a-input-search v-model:value="groupName" placeholder="群名称" style="width: 200px"
            @search="onSearch(groupName)" />
          <a-button class="search-head-button" type="primary" @click="add">add</a-button>
        </div>
      </a-layout-header>
      <a-layout-content class="mt-contents">
        <a-table :dataSource="group.list" :columns="group.columns" :pagination="false"
          :row-class-name="(_record: any, index: number) => (index % 2 === 1 ? 'table-striped' : null)">
          <template #bodyCell="{ column, record }">
            <template v-if="column.key === 'operate'">
              <span>
                <a-button type="link" @click="edit(record)">edit</a-button>
                <a-button type="link" @click="delect(record)">delect</a-button>
              </span>
            </template>
          </template>
        </a-table>
      </a-layout-content>
    </a-layout>
    <!-- 新增 -->
    <a-modal v-model:visible="visibleGroup" :title="title">
      <template #footer>
        <a-button key="back" @click="visibleGroup = !visibleGroup">取消</a-button>
        <a-button key="submit" type="primary" :disabled="disabledF" :loading="groupLoading" @click="addOk">确定</a-button>
      </template>
      <a-form :model="formState" :label-col="{ span: 6 }" :wrapper-col="{ span: 18 }">
        <a-form-item label="群名称" name="groupName" :rules="[{ required: true, message: '请输入群名称' }]">
          <a-input v-model:value="formState.groupName" />
        </a-form-item>
        <a-form-item label="群头像" name="groupName">
          <a-upload v-model:file-list="fileList" name="file" list-type="picture-card" class="avatar-uploader"
            :show-upload-list="false" action="/dood/platform/api2/material/upload?type=2" :headers="douheaders"
            :before-upload="beforeUpload" @change="handleChange">
            <img v-if="imageUrl" :src="imageUrl" alt="avatar" class="imgHead" />
            <div v-else>
              <loading-outlined v-if="loading"></loading-outlined>
              <plus-outlined v-else></plus-outlined>
              <div class="ant-upload-text">Upload</div>
            </div>
          </a-upload>
        </a-form-item>
        <a-form-item label="群级别" name="groupLevel" :rules="[{ required: true, message: '请选择群级别' }]">
          <a-select ref="select" v-model:value="formState.groupLevel" @change="selectChange($event)">
            <a-select-option v-for="item in type" :key="item['value']" :value="item['value']">{{ item['text']
            }}</a-select-option>
          </a-select>
        </a-form-item>
        <a-form-item label="群简介" name="groupBrief" :rules="[{ required: true, message: '请输入群简介' }]">
          <a-input v-model:value="formState.groupBrief" />
        </a-form-item>
        <a-form-item label="群公告" name="groupBulletin" :rules="[{ required: true, message: '请输入群公告' }]">
          <a-textarea v-model:value="formState.groupBulletin" placeholder="请输入群公告" :rows="4" />
        </a-form-item>
      </a-form>
    </a-modal>
    <person :visible="personVisible" :personList="rowData.personList" :from="rowData.from"
      @handleOk="handleOkperson($event)" @cancel="cancel()"></person>
    <a-modal v-model:visible="persVisible" title="群成员" @Ok="removeMember">
      <a-table rowKey="userID"  :row-selection="{ selectedRowKeys: selectedRowKeys, onChange: onSelectChange,}" :columns="perList.columns" :pagination="false" :data-source="perList.dataSource">
        <template #bodyCell="{ column, record }">
          <template v-if="column.key === 'sex'">
            <span>{{ record.sex ? '女' : '男' }}</span>
          </template>
          <template v-if="column.key === 'userID'">
            <span>{{ record.userID }}</span>
          </template>
        </template>
      </a-table>
    </a-modal>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted, reactive, computed } from 'vue';
import { PlusOutlined, LoadingOutlined } from '@ant-design/icons-vue';
import { message, Modal } from 'ant-design-vue';
import type { UploadChangeParam } from 'ant-design-vue';
import { DOUDOU, DOUDOUM } from '@/config/config';
import { creatGroup } from './form'
import { getgrouplist, getgroupd, createGroup, updateGroup, removeGroup, getMembers, addMembers, removeMembers } from '@/api/group/index';
import person from '@/components/personnel/index.vue';

/**
 * 数据列
 */
let visibleGroup = ref(false);
let groupLoading = ref(false)
let groupName = ref('');
const fileList = ref([]);
const loading = ref<boolean>(false);
const imageUrl = ref<string>('');
const douheaders = reactive({
  'access-token': sessionStorage.getItem('dou_token')
})
const title = ref('添加');
let formState = reactive<creatGroup>({
  groupName: '',
  groupIcon: '',
  groupType: '临时群',
  groupLevel: 1,
  groupBrief: '',
  groupBulletin: '',
  initGroupMembers: []
})
const type = ref([
  {
    value: 1,
    text: '临时群'
  },
  {
    value: 2,
    text: '普通群'
  },
  {
    value: 3,
    text: '高级群'
  },
  {
    value: 4,
    text: '超级群'
  },
])
const group = reactive({
  list: [],
  columns: [
    {
      title: 'color',
      dataIndex: 'groupName',
      key: 'groupName',
      align: 'center'
    },
    {
      title: 'inventory',
      dataIndex: 'groupIcon',
      key: 'groupIcon',
      align: 'center'
    },
    {
      title: 'operate',
      dataIndex: 'operate',
      key: 'operate',
      align: 'center'
    },
  ]
})

const persons = reactive({
  columns: [
    {
      title: '姓名',
      dataIndex: 'realname',
      key: 'realname',
      align: 'center'
    },
    {
      title: '用户ID',
      dataIndex: 'userID',
      key: 'userID',
      align: 'center'
    },
    {
      title: '操作',
      dataIndex: 'operate',
      key: 'operate',
      align: 'center'
    },
  ],
  data: [

  ]
})
const personVisible = ref(false);

const disabledF = computed(() => {
  return !(formState.groupName && formState.groupBrief && formState.groupBulletin);
});

onMounted(() => {
  getGroup()
})

// 获取群列表
const getGroup = () => {
  getgrouplist({ openID: DOUDOU.appID }).then((res: any) => {
    if (res.code == 0) {
      group.list = res.result;
    }
  })
}
const handleChange = (info: UploadChangeParam) => {
  if (info.file.status === 'uploading') {
    loading.value = true;
    return;
  }
  if (info.file.status === 'done') {
    getBase64(info.file.originFileObj, (base64Url: string) => {
      imageUrl.value = base64Url;
      loading.value = false;
    })
    if (info.file.response.code == 0) {
      formState.groupIcon = info.file.response.result.resourceUrl;
    } else {
      message.error(info.file.response.msg)
    }
  }
  if (info.file.status === 'error') {
    loading.value = false;
    message.error('上传失败');
  }
};

const beforeUpload = (file: any) => {
  const isJpgOrPng = file.type === 'image/jpeg' || file.type === 'image/png';
  if (!isJpgOrPng) {
    message.error('只支持.jpeg或者.png的图片!');
  }
  const isLt2M = file.size / 1024 / 1024 < 2;
  if (!isLt2M) {
    message.error('图片大小最大为2M!');
  }
  return isJpgOrPng && isLt2M;
};

function getBase64(img: any, callback: (base64Url: string) => void) {
  const reader = new FileReader();
  reader.addEventListener('load', () => callback(reader.result as string));
  reader.readAsDataURL(img);
}
const selectChange = (e: any) => {
  formState.groupType = type.value.find((item) => item.value == e)?.text;
  console.log(formState)
}
const onSearch = (groupName: string) => {
  console.log(groupName)
  getGroup()
}
const add = () => {
  visibleGroup.value = true;
  groupLoading.value = false;
  title.value = '添加';
  formState.groupName = '';
  formState.groupBrief = '';
  formState.groupBulletin = '';
  formState.groupIcon = '';
  formState.groupLevel = 1;
  formState.groupType = '临时群';
  formState.initGroupMembers = [];
  imageUrl.value = '';
}
const addOk = () => {
  groupLoading.value = true;
  if (title.value == '添加') {
    formState.initGroupMembers.push(DOUDOU.appID)
    formState.initGroupMembers.push(DOUDOUM.appID)
    createGroup(formState).then((res: any) => {
      if (res.code == 0) {
        getGroup()
        groupLoading.value = false;
        visibleGroup.value = false;
        message.success(res.msg);
      }
    })
  } else {
    updateGroup(formState).then((res: any) => {
      if (res.code == 0) {
        getGroup()
        groupLoading.value = false;
        visibleGroup.value = false;
        message.success(res.msg);
      }
    })
  }
}
const edit = async (e: any) => {
  const result: any = await getgroupd({ groupID: e.groupID })
  title.value = '编辑';
  if (result.code == 0) {
    formState = result.result;
    imageUrl.value = result.result.groupIcon;
    visibleGroup.value = true;
    groupLoading.value = false;
  }
}
const delect = (e: any) => {
  Modal.confirm({
    content: `你确定要解散(${e.groupName})群？`,
    onOk() {
      removeGroup({
        openID: DOUDOU.appID,
        groupID: e.groupID,
      }).then((res: any) => {
        if (res.code == 0) {
          message.success(res.msg);
          getGroup();
          Modal.destroyAll();
        }
      })
    },
    onCancel() {
      Modal.destroyAll();
    },
    cancelText: '取消',
    okText: '确定'
  })
}

//  选人后操作
const handleOkperson = (e: any) => {
  persons.data = e;
  addMember()
}
// 人员组件取消
const cancel = () => {
  personVisible.value = false
}
let rowData = reactive({
  value: {
    groupID: ''
  },
  from: 'add',
  personList: []
});
// 添加 群的人
const addGroupP = async (e: any) => {
  rowData.value = e;
  rowData.from = 'add';

  const data = {
    openID: DOUDOU.appID,
    groupID: rowData.value.groupID,
    pageNo: 1,
  }
  const result: any = await getMembers(data);
  if (result) {
    // 群里有的成员
    rowData.personList = result.result.userList;
    personVisible.value = true;
  }
}
const selectedRowKeys = ref([])
const onSelectChange = (selectedkey: any) => {
  selectedRowKeys.value = selectedkey;
}
// 移除 群里的人
const removeP = async (e: any) => {
  rowData.value = e;
  rowData.from = 'remove';
  selectedRowKeys.value = [];
  const data = {
    openID: DOUDOU.appID,
    groupID: rowData.value.groupID,
    pageNo: 1,
  }
  const result: any = await getMembers(data);
  if (result) {
    // 群里有的成员
    perList.dataSource = result.result.userList;
    persVisible.value = true;
  }
}

// 添加的人接口
const addMember = async () => {
  const data = {
    openID: DOUDOU.appID,
    groupID: rowData.value.groupID,
    groupMembers: persons.data.map((item: any) => item.userID)
  }
  const result = await addMembers(data);
  if (result) {
    message.success('添加成功');
    personVisible.value = false;
  }
}

// 移除群里人的接口
const removeMember = async () => {
  if(rowData.from != 'remove') {
    persVisible.value = false;
    return
  }
  const data = {
    openID: DOUDOU.appID,
    groupID: rowData.value.groupID,
    groupMembers: selectedRowKeys.value
  }
  const result = await removeMembers(data);
  if (result) {
    message.success('移除成功');
    persVisible.value = false;
  }
}
const persVisible = ref(false);
const perList = reactive({
  columns: [{
    title: '用户名',
    dataIndex: 'name',
    key: 'name',
    align: 'center'
  },
  {
    title: '性别',
    dataIndex: 'sex',
    key: 'sex',
    align: 'center'
  },
  {
    title: '用户ID',
    dataIndex: 'userID',
    key: 'userID',
    align: 'center'
  },],
  dataSource: []
})
const persClick = async (record: any) => {
  rowData.value = record;
  rowData.from = 'details'
  const data = {
    openID: DOUDOU.appID,
    groupID: record.groupID,
    pageNo: 1,
  }
  const result: any = await getMembers(data);
  if (result) {
    // 群里有的成员
    perList.dataSource = result.result.userList;
    persVisible.value = true;
  }
}
</script>

<style scoped lang="less">
.search-head {
  display: flex;
  height: 100%;
  align-items: center;
  justify-content: right;

  &-button {
    margin-left: 10px;
  }

}

.imgHead {
  width: 30px;
  height: 30px;
}
</style>