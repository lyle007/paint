<template>
  <div>
    <a-layout>
      <a-layout-header :style="{ background: '#fff', width: '100%', borderBottom: '1px solid #e7e7e7' }">
        <div class="search-head">
          <a-input-search v-model:value="searchData.search" placeholder="用户 名称" style="width: 200px"
            @search="onSearch()" />
          <a-button type="primary" style="margin-left: 10px;" @click="sync">手动同步用户</a-button>
        </div>
      </a-layout-header>
      <a-layout-content class="mt-contents">
        <a-table :dataSource="tableData.dataSource" :columns="tableData.columns" :pagination="false">
          <template #bodyCell="{ column, record }">
            <template v-if="column.key === 'sex'">
              <span>{{ record.sex ? '女' : '男' }}</span>
            </template>
          </template>
        </a-table>
        <a-pagination v-model:current="searchData.page" :total="count" size="small" show-less-items @change="changePage" />
      </a-layout-content>
    </a-layout>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive, onMounted } from 'vue';
import { getAllUserNew, synchronous } from '@/api/group/index';
import { Modal, message } from 'ant-design-vue';
const searchData = reactive({
  page: 1,
  rows: 10,
  search: ''
})
const count = ref(0);
const tableData = reactive({
  dataSource: [],
  columns: [
    {
      title: 'userName',
      dataIndex: 'userName',
      key: 'userName',
      align: 'center'
    },
    {
      title: 'name',
      dataIndex: 'name',
      key: 'name',
      align: 'center'
    },
    {
      title: 'passWordID',
      dataIndex: 'passWord',
      key: 'passWord',
      align: 'center'
    },
  ]
})
onMounted(() => {
  // getlist()
})
const getlist = () => {
  getAllUserNew(searchData).then((res: any) => {
    if (res.code == 0) {
      count.value = res.data.total
      tableData.dataSource = res.data.data;
    }
  })
}
const changePage = (page: number, size: number) => {
  searchData.page= page,
  searchData.rows = size
  getlist()
}

const onSearch = () => {
  getlist()
}
const sync = () => {
  Modal.confirm({
    content: '是否手动同步用户？',
    onCancel() {
      Modal.destroyAll();
    },
    onOk() {
      synchronous().then(()=> {
        message.success('同步成功')
      })
    },
  })
}
</script>

<style scoped lang="less">
.search-head {
  display: flex;
  height: 100%;
  align-items: center;
  justify-content: right;

  &-button {
    margin-left: 10px;
  }

}

.imgHead {
  width: 30px;
  height: 30px;
}
.mt-contents{
  overflow-y: auto;
}
</style>