<template>
  <div>
    <div class="mt-content-box">
      <div class="mt-login">
        <div class="login_window_name">
          <div class="login-logo">
          </div>
          <p>{{ platformName }}</p>
        </div>
        <div class="mt-login-content">
          <a-form :model="user" name="normal_login">
            <a-form-item name="account" :rules="[{ required: true, message: 'Please enter the user name' }]">
              <a-input v-model:value="user.account" :bordered="false" placeholder="user name">
                <template #prefix>
                  <user-outlined style="font-size: 18px;margin-left: 5px; margin-right: 5px" />
                </template>
              </a-input>
            </a-form-item>
            <a-form-item name="password" :rules="[{ required: true, message: 'Please enter the password' }]">
              <a-input-password v-model:value="user.password" :bordered="false" placeholder="password">
                <template #prefix>
                  <unlock-outlined style="font-size: 18px; margin-left: 5px; margin-right: 5px" />
                </template>
              </a-input-password>
            </a-form-item>
            <a-form-item name="password2" :rules="[{ required: true, message: '请输入密码2' }]" v-if="is_open">
              <a-input-password v-model:value="user.password2" :bordered="false" placeholder="管理员密码2">
                <template #prefix>
                  <unlock-outlined style="font-size: 18px; margin-left: 10px" />
                </template>
              </a-input-password>
            </a-form-item>
            <a-form-item name="password3" :rules="[{ required: true, message: '请输入密码3' }]" v-if="is_open">
              <a-input-password v-model:value="user.password3" :bordered="false" placeholder="管理员密码3">
                <template #prefix>
                  <unlock-outlined style="font-size: 18px; margin-left: 10px" />
                </template>
              </a-input-password>
            </a-form-item>
            <a-form-item name="ver" :rules="[{ required: true, message: '请输入验证码' }]" v-if="verShow">
              <div class="codes">
                <a-input v-model:value="user.ver" :bordered="false" placeholder="验证码">
                  <template #prefix>
                    <code-outlined style="font-size: 18px;margin-left: 10px" />
                  </template>
                </a-input>
                <img :src="codeImg" alt="" @click="randomImg">
              </div>
            </a-form-item>
            <div class="login-button">
              <a-button type="primary" @click="login()" :loading="loading" :disabled="disabledLogin">login</a-button>
            </div>
            <div class="error_mess">
              {{ errorMessage }}
            </div>
          </a-form>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { onMounted, ref, computed, reactive, onUnmounted } from 'vue'
import { useRouter, useRoute } from 'vue-router';
import {
  UserOutlined,
  UnlockOutlined,
  CodeOutlined
} from '@ant-design/icons-vue';

import { loginToken, getVerImg, getAdmin } from '@/api/login'
import { useCounterStore } from '@/store/index'
const useStore = useCounterStore()

const user = reactive({
  tenant_id: 'msap',
  account: '',
  password: '',
  password2: '',
  password3: '',
  ver: '',
  udid: ''
})
// 错误消息提示
let errorMessage = ref('')
let platformName = ref('Paint management')
const router = useRouter();
const route = useRoute();
const loading = ref(false)
// 判断按钮是否登录
const disabledLogin = computed(() => {
  return !user.tenant_id && !user.account && !user.password
})
onMounted(() => {
  user.tenant_id = route.query.id as any;
  window.addEventListener('keydown', keyDown)
})
onUnmounted(() => {
  window.removeEventListener('keydown', keyDown, false)
})
const keyDown = (e: any) => {
  //如果是回车则执行登录方法
  if (e.keyCode == 13) {
    login()
  }
}
let is_open = ref(0)
const login = () => {
  loading.value = true;
  loginToken(user).then(async (res: any) => {
    // if (res.data.is_open == 1) {
    //   is_open.value = 1;
    //   if (!user.password2 && !user.password3) {
    //     randomImg()
    //     return
    //   }
    // }

    sessionStorage.setItem('access_token', res.access_token);
    router.push({
      path: '/'
    })
    loading.value = false;
  }).catch((error: any) => {
    errorMessage.value = error.response.data.error_description;
    loading.value = false;
  })
}
// const getTenant = (id: string) => {
//   if (!id || id == 'msap') return;
// }

// const  = (num: numbreLoginer) => {
//   if (num) {
//     randomImg();
//   }
// }
let codeImg = ref('');
let verShow = ref(false)

const randomImg = () => {
  user.udid = new Date().getTime() + JSON.stringify(Math.round(Math.random() * 100));
  return
  getVerImg(user.udid, user.tenant_id).then(async (res: any) => {
    if (res.size > 0) {
      codeImg.value = await getDataURL(res, 'image/png') as any;
      if (user.tenant_id) {
        verShow.value = true;
      } else {
        verShow.value = false;
      }
    }
  })
}

function getDataURL(data: Blob, type: string) {
  return new Promise((resolve, reject) => {
    const blob = new Blob([data], {
      type
    });
    const reader = new FileReader();
    reader.readAsDataURL(blob);
    reader.onload = () => resolve(reader.result);
    reader.onerror = (error) => reject(error);
  });
}
</script>

<style scoped lang="less">
.mt-content-box {
  display: flex;
  width: 100%;
  height: 100vh;
  background-color: white;
  justify-content: center;
  align-items: center;
}

.mt-login {
  width: 500px;
  box-shadow: 0 0 15px #00000075;
  border-radius: 15px;
  // height: 100px;
  background-color: #fff;
  padding: 20px 20px 30px;
}

.mt-login-content {
  padding: 0 50px;
}

.login_window_name {
  font-size: 28px;
  font-weight: 700;
  text-align: center;

  p {
    margin-bottom: 30px;
  }
}

.login-item {
  width: 80%;
  display: flex;
  border-bottom: 1px solid #e2e2e2;
  height: 44px;
  align-items: center;
  margin: 0 13%;
}

// 提示文字的样式
:deep(.ant-form-item-with-help .ant-form-item-explain) {
  padding-left: 20px;
}

:deep(.ant-form-item-control-input-content) {
  border-bottom: 1px solid #e2e2e2;
  height: 44px;
  line-height: 44px;
}

.login-button {
  button {
    width: 100%;
    height: 40px;
    border-radius: 40px;
  }
}

.error_mess {
  color: red;
  text-align: center;
}

.codes {
  display: flex;
}

.login-logo {
  width: 100%;
  margin-bottom: 10px;

  img {
    margin: 0 auto;
    height: 60px;
  }
}
</style>