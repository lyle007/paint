/// <reference types="vite/client" />

declare module 'vue-grid-layout'{
    import VueGridLayout from 'vue-grid-layout'
    export default VueGridLayout
}  

declare module 'js-md5'{
    import md5 from 'js-md5'
    export default md5
}

