import { defineConfig, loadEnv } from 'vite'
import path, { resolve } from 'path';
import vue from '@vitejs/plugin-vue';
import { visualizer } from 'rollup-plugin-visualizer';

import { createSvgIconsPlugin } from 'vite-plugin-svg-icons';

// https://vitejs.dev/config/
export default defineConfig(({ command, mode }) => {
  // 获取环境变量
  const env = loadEnv(mode, process.cwd());  
  console.log(command)
  return {
    plugins: [vue(), visualizer(), createSvgIconsPlugin({
      // 指定需要缓存的图标文件夹
      iconDirs: [path.resolve(process.cwd(), 'src/assets/svg')],
      symbolId: '[name]'
    })],
    base: env.VITE_API_WEBBASEURL,
    resolve: {
      alias: {
        '@': resolve(__dirname, './src')
      }
    },
    server: {
      host: true, // 可以ip访问，
      port: 8082, // 端口
      open: true, // 直接打开浏览器
      cors: true, // 允许跨域
      proxy: {
        '/sap': {
          target: env.VITE_API_PROXY,  // 地址
          changeOrigin: true,
          secure: false,
          rewrite: (path) => path.replace('/sap/', '/sap/'),
        },
        '/common': {
          target: env.VITE_API_PROXY,
          changeOrigin: true,
          secure: false,
          rewrite: (path) => path.replace('/common/', '/common/'),
        },
        '/pms': {
          target: env.VITE_API_PROXY,
          changeOrigin: true,
          secure: false,
          rewrite: (path) => path.replace('/pms/', '/pms/'),
        },
        '/uaa': {
          target: env.VITE_API_PROXY,
          changeOrigin: true,
          secure: false,
          rewrite: (path) => path.replace('/uaa/', '/uaa/'),
        },
        '/dood': {
          target: 'https://mx.magictechnology.com:10669',
          changeOrigin: true,
          secure: false,
          rewrite: (path) => path.replace('/dood/', '/'),
        },
        '/ecs': {
          target: env.VITE_API_PROXY,
          changeOrigin: true,
          secure: false,
          rewrite: (path) => path.replace('/ecs/', '/ecs/'),
        },
        '/ecc': {
          target: env.VITE_API_PROXY,
          changeOrigin: true,
          secure: false,
          rewrite: (path) => path.replace('/ecc/', '/ecc/'),
        },
      }
    },
    build: {
      chunkSizeWarningLimit: 1000, // 文件超过 2M 告警
      assetsDir: 'static/assets',
      outDir: 'webecc',
      rollupOptions: {
        output: {
          chunkFileNames: 'static/js/[name]-[hash].js',
          entryFileNames: 'static/js/[name]-[hash].js',
          assetFileNames: 'static/[ext]/[name]-[hash].[ext]',
        },
      }
    },
    css: {
      preprocessorOptions: {
        less: {
          javascriptEnabled: true,
          modifyVars: {},
        },
      },
    },
  }
})
